plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.banglavoice"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.banglavoice"
        minSdk = 28
        targetSdk = 34
        versionCode = 4
        versionName = "0.4"
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    // Only for FileProvider (sharing the PDFs the assistant makes).
    implementation("androidx.core:core:1.13.1")
}
