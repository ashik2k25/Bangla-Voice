package com.example.banglavoice

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        fun label(t: String) = TextView(this).apply {
            text = t
            textSize = 15f
            setPadding(0, pad / 2, 0, pad / 4)
        }

        fun button(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t
            setOnClickListener { onClick() }
        }

        col.addView(TextView(this).apply { text = "BanglaVoice"; textSize = 24f })
        status = label("")
        col.addView(status)

        col.addView(label("1) Gemini API key (aistudio.google.com/apikey)"))
        val key = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(Prefs.apiKey(this@MainActivity))
        }
        col.addView(key)

        col.addView(label("2) Voice language (Bangla = bn-BD)"))
        val lang = EditText(this).apply { setText(Prefs.language(this@MainActivity)) }
        col.addView(lang)

        col.addView(button("Save") {
            Prefs.save(this, key.text.toString().trim(), lang.text.toString().trim().ifEmpty { "bn-BD" })
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        })
        col.addView(button("3) Mic permission dao") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        })
        col.addView(button("4) Accessibility chalu koro") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(label("Accessibility te BanglaVoice ON korle screen e nil mic button ashbe. Tap kore Bangla te bolo."))

        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        status.text = if (AssistantService.instance != null) "Service: ON" else "Service: OFF (step 4 koro)"
    }
}
