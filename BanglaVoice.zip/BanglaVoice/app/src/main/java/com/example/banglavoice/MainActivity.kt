package com.example.banglavoice

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        fun label(t: String) = TextView(this).apply {
            text = t
            textSize = 15f
            setPadding(0, pad / 2, 0, pad / 4)
        }

        fun button(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t
            setOnClickListener { onClick() }
        }

        col.addView(TextView(this).apply { text = "BanglaVoice"; textSize = 24f })
        status = label("")
        col.addView(status)

        col.addView(label("1) Gemini API key (aistudio.google.com/apikey)"))
        val key = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(Prefs.apiKey(this@MainActivity))
        }
        col.addView(key)

        col.addView(label("2) Gemini model (khali rakho = auto)"))
        val model = EditText(this).apply { setText(Prefs.model(this@MainActivity)) }
        col.addView(model)

        col.addView(label("3) Dakar nam (Gemini ke bole dey)"))
        val wake = EditText(this).apply { setText(Prefs.wake(this@MainActivity)) }
        col.addView(wake)

        col.addView(label("4) Kotokkhon chup thakle Ara ghumabe (minute, 0 = 'ghumao' na bola porjonto jaga thakbe)"))
        val mins = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(Prefs.sessionMinutes(this@MainActivity).toString())
        }
        col.addView(mins)

        col.addView(button("Save") {
            Prefs.save(
                this,
                key.text.toString().trim(),
                model.text.toString().trim(),
                wake.text.toString().trim().ifEmpty { Prefs.DEFAULT_WAKE },
                mins.text.toString().trim().toIntOrNull() ?: 10
            )
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        })
        col.addView(button("5) Mic + notification permission dao") {
            requestPermissions(
                arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS),
                1
            )
        })
        col.addView(button("6) Accessibility chalu koro") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(button("Hands-free abar shuru koro (dorkar hole)") {
            stopService(Intent(this, WakeService::class.java))
            startForegroundService(Intent(this, WakeService::class.java))
            refreshStatus()
        })
        col.addView(button("Hands-free BONDHO") {
            stopService(Intent(this, WakeService::class.java))
            refreshStatus()
        })
        col.addView(button("Ara ja shikheche shob muche felo") {
            Lessons.clear(this)
            refreshStatus()
        })
        col.addView(label("Kotha bolar niyom: 'Ara' bole ektu thamo, bip shunle kotha bolo. Ara jaga thakle bar bar dakte hobe na. 'Ara ghumao' bolle ghumabe. Kaj cholar shomoy 'thamo' bolle kaj thamabe."))
        col.addView(label("Shekhano: bhul korle 'Ara bhul korcho, ...' bolo. Dekhiye shekhate 'Ara shekhachchi' bole nijer haate kore dekhao, shesh hole 'Ara shesh' bolo."))
        col.addView(label("Nil gol button e tap: jaga/ghum, kaj cholar shomoy thamano. Battery: Settings > Apps > BanglaVoice > Battery > Unrestricted."))

        setContentView(ScrollView(this).apply { addView(col) })

        // Start hands-free automatically, no need to switch it on by hand.
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED && !WakeService.running) {
            startForegroundService(Intent(this, WakeService::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun refreshStatus() {
        val svc = if (AssistantService.instance != null) "Accessibility: ON" else "Accessibility: OFF (step 6 koro)"
        val hf = if (WakeService.running) "Hands-free: ON" else "Hands-free: OFF"
        status.text = "$svc\n$hf\nShikheche: ${Lessons.count(this)} ta"
    }
}
