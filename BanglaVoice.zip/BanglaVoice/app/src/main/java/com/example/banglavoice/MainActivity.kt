package com.example.banglavoice

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        fun label(t: String) = TextView(this).apply {
            text = t
            textSize = 15f
            setPadding(0, pad / 2, 0, pad / 4)
        }

        fun button(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t
            setOnClickListener { onClick() }
        }

        col.addView(TextView(this).apply { text = "BanglaVoice"; textSize = 24f })
        status = label("")
        col.addView(status)

        col.addView(label("1) Gemini API key (aistudio.google.com/apikey)"))
        val key = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(Prefs.apiKey(this@MainActivity))
        }
        col.addView(key)

        col.addView(label("2) Voice language (Bangla = bn-BD)"))
        val lang = EditText(this).apply { setText(Prefs.language(this@MainActivity)) }
        col.addView(lang)

        col.addView(label("3) Gemini model (khali rakho = auto)"))
        val model = EditText(this).apply { setText(Prefs.model(this@MainActivity)) }
        col.addView(model)

        col.addView(label("4) Dakar nam (comma diye, ek nam er onek banan)"))
        val wake = EditText(this).apply { setText(Prefs.wake(this@MainActivity)) }
        col.addView(wake)

        col.addView(button("Save") {
            Prefs.save(
                this,
                key.text.toString().trim(),
                lang.text.toString().trim().ifEmpty { "bn-BD" },
                model.text.toString().trim(),
                wake.text.toString().trim().ifEmpty { Prefs.DEFAULT_WAKE }
            )
            Toast.makeText(this, "Saved. Hands-free chalu thakle bondho kore abar chalu koro.", Toast.LENGTH_LONG).show()
        })
        col.addView(button("5) Mic + notification permission dao") {
            requestPermissions(
                arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS),
                1
            )
        })
        col.addView(button("6) Accessibility chalu koro") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(button("7) Hands-free CHALU (nam dhore dako)") {
            startForegroundService(Intent(this, WakeService::class.java))
            Toast.makeText(this, "Chalu. Ekhon nam dhore dako.", Toast.LENGTH_SHORT).show()
        })
        col.addView(button("Hands-free BONDHO") {
            stopService(Intent(this, WakeService::class.java))
        })
        col.addView(label("Nil button e tap korleo kaj kore. Kaj cholar shomoy button e tap korle thame."))
        col.addView(label("Battery: Settings > Apps > BanglaVoice > Battery > Unrestricted dile hands-free bondho hoy na."))

        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        val svc = if (AssistantService.instance != null) "Service: ON" else "Service: OFF (step 6 koro)"
        val hf = if (WakeService.running) "Hands-free: ON" else "Hands-free: OFF"
        status.text = "$svc   |   $hf"
    }
}
