package com.example.banglavoice

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.widget.Toast
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors
import kotlin.math.sqrt

/**
 * The "ears". Records the microphone itself (no Google speech recogniser, so no beeps).
 *
 *  - SLEEPING: only short sounds are checked, and only a short clip goes to Gemini, which decides
 *    whether it was the name "Ara". Everything else is ignored silently.
 *  - SESSION (after the name): every sentence you say is sent to Gemini, which transcribes it and
 *    says if it is a command, a stop, a correction, etc. Stays on until you say stop / sleep, or
 *    the idle time set in the app runs out.
 */
class WakeService : Service() {

    companion object {
        @Volatile var running = false
        @Volatile var session = false
        @Volatile var instance: WakeService? = null
        private const val CHANNEL = "wake"
        private const val SR = 16000
        private const val FRAME = 320 // 20 ms
    }

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()

    @Volatile private var alive = false
    @Volatile private var workerBusy = false
    @Volatile private var lastActivity = 0L
    @Volatile private var deafUntil = 0L
    @Volatile private var limitMs = 0L
    private var thread: Thread? = null
    private val sleepChecks = java.util.ArrayDeque<Long>()
    private val sessionChecks = java.util.ArrayDeque<Long>()
    private var lastErrToast = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            startInForeground()
        } catch (e: Exception) {
            Toast.makeText(this, "Hands-free shuru hoy ni: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }
        if (!running) {
            running = true
            alive = true
            instance = this
            AssistantService.instance?.refreshButton()
            thread = Thread { audioLoop() }.also { it.start() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        alive = false
        running = false
        session = false
        instance = null
        main.removeCallbacksAndMessages(null)
        AssistantService.instance?.refreshButton()
        super.onDestroy()
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "BanglaVoice hands-free", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, WakeService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("BanglaVoice")
            .setContentText("Ara bole dako. Bondho korte niche chapo.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Bondho koro", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun errorToast(msg: String) {
        val now = System.currentTimeMillis()
        if (now - lastErrToast > 30000) {
            lastErrToast = now
            main.post { toast(msg) }
        }
    }

    // ---------- session control (main thread) ----------
    fun toggleSession() {
        if (session) endSession() else startSession()
    }

    private fun startSession() {
        if (session) return
        limitMs = Prefs.sessionMinutes(this) * 60_000L
        lastActivity = System.currentTimeMillis()
        session = true
        beep(true)
        toast("Ara shunche")
        AssistantService.instance?.refreshButton()
    }

    private fun endSession() {
        if (!session) return
        session = false
        beep(false)
        toast("Ara ghumalo. Abar dakte 'Ara' bolo")
        AssistantService.instance?.refreshButton()
    }

    private fun beep(up: Boolean) {
        deafUntil = System.currentTimeMillis() + 700
        runCatching {
            val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80)
            tg.startTone(if (up) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_BEEP2, 150)
            main.postDelayed({ tg.release() }, 700)
        }
    }

    // ---------- listening ----------
    private fun audioLoop() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            main.post {
                toast("Mic permission nei")
                stopSelf()
            }
            return
        }
        val minBuf = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION, SR,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, SR * 2)
        )
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            main.post {
                toast("Mic chalu hoy ni")
                stopSelf()
            }
            return
        }
        rec.startRecording()

        val frame = ShortArray(FRAME)
        val pre = java.util.ArrayDeque<ShortArray>()
        var seg = ArrayList<ShortArray>()
        var speaking = false
        var skipping = false
        var speechFrames = 0
        var silence = 0
        var noise = 150.0
        try {
            while (alive) {
                val n = rec.read(frame, 0, FRAME)
                if (n < 0) break
                if (n == 0) continue

                var sum = 0.0
                for (i in 0 until n) {
                    val v = frame[i].toDouble()
                    sum += v * v
                }
                val rms = sqrt(sum / n)
                val now = System.currentTimeMillis()
                val isSpeech = rms > maxOf(350.0, noise * 3.0) && now > deafUntil
                if (!speaking && !isSpeech) noise = (noise * 0.98 + rms * 0.02).coerceIn(50.0, 1500.0)

                // session idle timeout
                if (session) {
                    val svc = AssistantService.instance
                    if (speaking || (svc != null && svc.engaged())) {
                        lastActivity = now
                    } else if (limitMs > 0 && now - lastActivity > limitMs) {
                        main.post { endSession() }
                    }
                }

                // long speech while sleeping = a conversation, ignore it until it pauses
                if (skipping) {
                    if (isSpeech) silence = 0 else silence++
                    if (silence >= 30) {
                        skipping = false
                        silence = 0
                    }
                    continue
                }

                if (!speaking) {
                    pre.addLast(frame.copyOf(n))
                    if (pre.size > 15) pre.removeFirst()
                    if (isSpeech) {
                        speaking = true
                        seg = ArrayList(pre)
                        pre.clear()
                        speechFrames = 1
                        silence = 0
                    }
                } else {
                    seg.add(frame.copyOf(n))
                    if (isSpeech) {
                        speechFrames++
                        silence = 0
                    } else {
                        silence++
                    }
                    val inSession = session
                    val endSilence = if (inSession) 45 else 30
                    val maxFrames = if (inSession) 1000 else 150
                    if (silence >= endSilence) {
                        val done = seg
                        val sf = speechFrames
                        speaking = false
                        seg = ArrayList()
                        speechFrames = 0
                        silence = 0
                        onSegment(done, sf)
                    } else if (seg.size >= maxFrames) {
                        val done = seg
                        val sf = speechFrames
                        speaking = false
                        seg = ArrayList()
                        speechFrames = 0
                        silence = 0
                        if (inSession) {
                            onSegment(done, sf)
                        } else {
                            skipping = true
                        }
                    }
                }
            }
        } finally {
            runCatching { rec.stop() }
            rec.release()
        }
    }

    private fun rateOk(q: java.util.ArrayDeque<Long>, max: Int): Boolean {
        val now = System.currentTimeMillis()
        while (q.isNotEmpty() && now - q.first() > 60_000) q.removeFirst()
        if (q.size >= max) return false
        q.addLast(now)
        return true
    }

    private fun onSegment(seg: List<ShortArray>, speechFrames: Int) {
        if (speechFrames * 20 < 250) return
        if (workerBusy) return
        val inSession = session
        if (!rateOk(if (inSession) sessionChecks else sleepChecks, if (inSession) 12 else 5)) return

        var total = 0
        for (f in seg) total += f.size
        val pcm = ShortArray(total)
        var o = 0
        for (f in seg) {
            System.arraycopy(f, 0, pcm, o, f.size)
            o += f.size
        }
        workerBusy = true
        worker.execute {
            try {
                handle(pcm, inSession)
            } finally {
                workerBusy = false
            }
        }
    }

    private fun handle(pcm: ShortArray, inSession: Boolean) {
        val h = try {
            GeminiClient.hear(this, wav(pcm), Prefs.wake(this))
        } catch (e: Exception) {
            errorToast("Error: ${e.message}")
            return
        }
        if (!inSession) {
            if (!h.wake) return // not the name, stay silent
            main.post {
                startSession()
                dispatch(h)
            }
        } else {
            if (h.kind == "noise") return
            main.post { dispatch(h) }
        }
    }

    private fun dispatch(h: Heard) {
        lastActivity = System.currentTimeMillis()
        val svc = AssistantService.instance
        if (svc == null) {
            toast("Accessibility chalu nei (app kholo)")
            return
        }
        when (h.kind) {
            "command" -> if (h.text.isNotBlank()) svc.runCommand(h.text)
            "stop_task" -> svc.cancel()
            "end_session" -> endSession()
            "yes" -> svc.answer(true)
            "no" -> svc.answer(false)
            "lesson" -> svc.learn(h.text)
            "teach_start" -> svc.teachStart(h.text)
            "teach_end" -> svc.teachEnd()
            else -> {}
        }
    }

    private fun wav(pcm: ShortArray): ByteArray {
        val dataLen = pcm.size * 2
        val bb = ByteBuffer.allocate(44 + dataLen).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray())
        bb.putInt(36 + dataLen)
        bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray())
        bb.putInt(16)
        bb.putShort(1.toShort())
        bb.putShort(1.toShort())
        bb.putInt(SR)
        bb.putInt(SR * 2)
        bb.putShort(2.toShort())
        bb.putShort(16.toShort())
        bb.put("data".toByteArray())
        bb.putInt(dataLen)
        for (s in pcm) bb.putShort(s)
        return bb.array()
    }
}
