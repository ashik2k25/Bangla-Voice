package com.example.banglavoice

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast

/**
 * Foreground service that keeps listening for the wake name (default "Ara").
 * When it hears the name it hands the rest of the sentence (or the next sentence) to AssistantService.
 */
class WakeService : Service() {

    companion object {
        @Volatile
        var running = false
        private const val CHANNEL = "wake"
    }

    private val main = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var words: List<String> = emptyList()
    private var warned = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        startInForeground()
        if (!running) {
            running = true
            words = Prefs.wake(this).split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
            AssistantService.instance?.refreshButton()
            main.post { loop() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        rec?.destroy()
        rec = null
        AssistantService.instance?.refreshButton()
        super.onDestroy()
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "BanglaVoice hands-free", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, WakeService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("BanglaVoice shunche")
            .setContentText("Nam dhore dako. Bondho korte niche chapo.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Bondho koro", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }

    private fun loop() {
        if (!running) return
        val svc = AssistantService.instance
        if (svc == null || svc.engaged()) {
            main.postDelayed({ loop() }, 700)
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Mic permission nei", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        rec?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onError(error: Int) {
                val quiet = error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                var delay = if (quiet) 250L else 1500L
                if (error == 12 || error == 13) { // language not supported / not available
                    if (!warned) {
                        warned = true
                        Toast.makeText(this@WakeService, "Bangla voice pack nei (code $error)", Toast.LENGTH_LONG).show()
                    }
                    delay = 10000L
                }
                main.postDelayed({ loop() }, delay)
            }

            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) onHeard(t)
                main.postDelayed({ loop() }, 250)
            }
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.language(this@WakeService))
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        r.startListening(intent)
    }

    private fun onHeard(text: String) {
        val orig = text.split(Regex("[\\s,।.!?]+")).filter { it.isNotEmpty() }
        val idx = orig.take(3).indexOfFirst { it.lowercase() in words }
        if (idx < 0) return
        val svc = AssistantService.instance ?: return
        val cmd = orig.drop(idx + 1).joinToString(" ")
        if (cmd.length >= 2) {
            svc.runCommand(cmd)
        } else {
            svc.signal()
            main.postDelayed({
                svc.listenOnce { t -> if (!t.isNullOrBlank()) svc.runCommand(t) }
            }, 400)
        }
    }
}
