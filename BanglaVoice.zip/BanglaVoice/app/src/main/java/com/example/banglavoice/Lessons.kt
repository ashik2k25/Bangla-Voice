package com.example.banglavoice

import android.content.Context
import org.json.JSONArray

/**
 * The "self-learning" memory, in two shelves:
 *  - lessons: corrections and demonstrations from the user (always shown if relevant)
 *  - skills: short summaries of tasks that finished without errors ("worked before")
 * The most relevant ones are shown to Gemini on every step.
 */
object Lessons {
    private fun sp(c: Context) = c.getSharedPreferences("lessons", Context.MODE_PRIVATE)

    private fun read(c: Context, key: String): MutableList<String> {
        val arr = try { JSONArray(sp(c).getString(key, "[]")) } catch (e: Exception) { JSONArray() }
        return MutableList(arr.length()) { arr.getString(it) }
    }

    private fun write(c: Context, key: String, l: List<String>) {
        sp(c).edit().putString(key, JSONArray(l).toString()).apply()
    }

    fun count(c: Context): Int = read(c, "list").size + read(c, "skills").size

    fun clear(c: Context) {
        sp(c).edit().putString("list", "[]").putString("skills", "[]").apply()
    }

    fun add(c: Context, lesson: String) {
        val l = read(c, "list")
        l.add(lesson.take(700))
        while (l.size > 40) l.removeAt(0)
        write(c, "list", l)
    }

    fun addSkill(c: Context, goal: String, summary: String) {
        val l = read(c, "skills")
        l.add("Goal '${goal.take(80)}' finished OK with: ${summary.take(420)}")
        while (l.size > 30) l.removeAt(0)
        write(c, "skills", l)
    }

    private fun tokens(s: String): Set<String> =
        s.lowercase().split(Regex("[^\\p{L}\\p{M}\\p{N}]+")).filter { it.length >= 2 }.toSet()

    /** Lessons that share words with this goal, plus the newest few. */
    fun relevant(c: Context, goal: String): String {
        val l = read(c, "list")
        if (l.isEmpty()) return ""
        val gt = tokens(goal)
        val scored = l.mapIndexed { i, s -> Triple(i, s, tokens(s).count { it in gt }) }
        val pick = (scored.filter { it.third > 0 }.sortedByDescending { it.third }.take(6) + scored.takeLast(4))
            .distinctBy { it.first }
            .sortedBy { it.first }
        return pick.joinToString("\n") { "- " + it.second }
    }

    /** Up to 3 earlier successful tasks that look similar to this goal. */
    fun relevantSkills(c: Context, goal: String): String {
        val l = read(c, "skills")
        if (l.isEmpty()) return ""
        val gt = tokens(goal)
        return l.map { s -> s to tokens(s).count { it in gt } }
            .filter { it.second >= 2 }
            .sortedByDescending { it.second }
            .take(3)
            .joinToString("\n") { "- " + it.first }
    }
}
