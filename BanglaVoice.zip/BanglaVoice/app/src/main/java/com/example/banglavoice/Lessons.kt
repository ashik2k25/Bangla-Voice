package com.example.banglavoice

import android.content.Context
import org.json.JSONArray

/**
 * The "self-learning" memory. Corrections and demonstrations are saved here and the most relevant
 * ones are shown to Gemini on every step, so the same mistake is not repeated.
 */
object Lessons {
    private fun sp(c: Context) = c.getSharedPreferences("lessons", Context.MODE_PRIVATE)

    private fun all(c: Context): MutableList<String> {
        val arr = try { JSONArray(sp(c).getString("list", "[]")) } catch (e: Exception) { JSONArray() }
        return MutableList(arr.length()) { arr.getString(it) }
    }

    fun count(c: Context): Int = all(c).size

    fun clear(c: Context) {
        sp(c).edit().putString("list", "[]").apply()
    }

    fun add(c: Context, lesson: String) {
        val l = all(c)
        l.add(lesson.take(700))
        while (l.size > 40) l.removeAt(0)
        sp(c).edit().putString("list", JSONArray(l).toString()).apply()
    }

    private fun tokens(s: String): Set<String> =
        s.lowercase().split(Regex("[^\\p{L}\\p{M}\\p{N}]+")).filter { it.length >= 2 }.toSet()

    /** The lessons that share words with this goal, plus the newest few. */
    fun relevant(c: Context, goal: String): String {
        val l = all(c)
        if (l.isEmpty()) return ""
        val gt = tokens(goal)
        val scored = l.mapIndexed { i, s -> Triple(i, s, tokens(s).count { it in gt }) }
        val pick = (scored.filter { it.third > 0 }.sortedByDescending { it.third }.take(6) + scored.takeLast(4))
            .distinctBy { it.first }
            .sortedBy { it.first }
        return pick.joinToString("\n") { "- " + it.second }
    }
}
