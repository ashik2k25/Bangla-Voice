package com.example.banglavoice

import android.content.Context

/** Simple local settings. API key is stored in this app's private storage only. */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun apiKey(c: Context): String = sp(c).getString("key", "") ?: ""
    fun language(c: Context): String = sp(c).getString("lang", "bn-BD") ?: "bn-BD"

    /** Empty = app tries its built-in list of free models automatically. */
    fun model(c: Context): String = sp(c).getString("model", "") ?: ""

    /** Comma separated names that wake the assistant. Speech recognition spells names differently, so list variants. */
    fun wake(c: Context): String = sp(c).getString("wake", DEFAULT_WAKE) ?: DEFAULT_WAKE

    const val DEFAULT_WAKE = "আরা, ara, aara, আড়া, অরা"

    fun save(c: Context, key: String, lang: String, model: String, wake: String) {
        sp(c).edit()
            .putString("key", key)
            .putString("lang", lang)
            .putString("model", model)
            .putString("wake", wake)
            .apply()
    }
}
