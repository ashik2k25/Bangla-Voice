package com.example.banglavoice

import android.content.Context

/** Simple local settings. The API key is stored encrypted (Android Keystore). */
object Prefs {
    const val DEFAULT_WAKE = "আরা, Ara, আড়া, Aara"

    private fun sp(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun apiKey(c: Context): String {
        val enc = sp(c).getString("key_enc", "") ?: ""
        if (enc.isNotEmpty()) return Secure.decrypt(enc)
        // older versions stored the key in plain text: move it into the encrypted slot once
        val old = sp(c).getString("key", "") ?: ""
        if (old.isNotEmpty()) {
            sp(c).edit().putString("key_enc", Secure.encrypt(old)).remove("key").apply()
        }
        return old
    }

    /** Empty = app picks from its built-in list of free models automatically (used for the agent only). */
    fun model(c: Context): String = sp(c).getString("model", "") ?: ""

    /** Name variants, only used to tell Gemini what the assistant is called. */
    fun wake(c: Context): String = sp(c).getString("wake", DEFAULT_WAKE) ?: DEFAULT_WAKE

    /** Minutes of silence before the hands-free session sleeps again. 0 = never (until you say stop). */
    fun sessionMinutes(c: Context): Int = sp(c).getInt("sess", 10)

    fun save(c: Context, key: String, model: String, wake: String, sessionMinutes: Int) {
        sp(c).edit()
            .putString("key_enc", if (key.isEmpty()) "" else Secure.encrypt(key))
            .remove("key")
            .putString("model", model)
            .putString("wake", wake)
            .putInt("sess", sessionMinutes.coerceAtLeast(0))
            .apply()
    }
}
