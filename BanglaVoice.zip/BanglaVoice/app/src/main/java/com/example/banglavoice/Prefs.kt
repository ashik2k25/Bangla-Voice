package com.example.banglavoice

import android.content.Context

/** Simple local settings. API key is stored in this app's private storage only. */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun apiKey(c: Context): String = sp(c).getString("key", "") ?: ""
    fun language(c: Context): String = sp(c).getString("lang", "bn-BD") ?: "bn-BD"
    /** Empty = app tries its built-in list of free models automatically. */
    fun model(c: Context): String = sp(c).getString("model", "") ?: ""

    fun save(c: Context, key: String, lang: String, model: String) {
        sp(c).edit().putString("key", key).putString("lang", lang).putString("model", model).apply()
    }
}
