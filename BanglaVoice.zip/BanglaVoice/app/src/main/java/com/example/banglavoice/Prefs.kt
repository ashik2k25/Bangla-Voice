package com.example.banglavoice

import android.content.Context

/** Simple local settings. API key is stored in this app's private storage only. */
object Prefs {
    const val DEFAULT_WAKE = "আরা, Ara, আড়া, Aara"

    private fun sp(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun apiKey(c: Context): String = sp(c).getString("key", "") ?: ""

    /** Empty = app tries its built-in list of free models automatically. */
    fun model(c: Context): String = sp(c).getString("model", "") ?: ""

    /** Name variants, only used to tell Gemini what the assistant is called. */
    fun wake(c: Context): String = sp(c).getString("wake", DEFAULT_WAKE) ?: DEFAULT_WAKE

    /** Minutes of silence before the hands-free session sleeps again. 0 = never (until you say stop). */
    fun sessionMinutes(c: Context): Int = sp(c).getInt("sess", 10)

    fun save(c: Context, key: String, model: String, wake: String, sessionMinutes: Int) {
        sp(c).edit()
            .putString("key", key)
            .putString("model", model)
            .putString("wake", wake)
            .putInt("sess", sessionMinutes.coerceAtLeast(0))
            .apply()
    }
}
