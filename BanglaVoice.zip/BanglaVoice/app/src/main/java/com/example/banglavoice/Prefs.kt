package com.example.banglavoice

import android.content.Context

/** Simple local settings. API key is stored in this app's private storage only. */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun apiKey(c: Context): String = sp(c).getString("key", "") ?: ""
    fun language(c: Context): String = sp(c).getString("lang", "bn-BD") ?: "bn-BD"

    fun save(c: Context, key: String, lang: String) {
        sp(c).edit().putString("key", key).putString("lang", lang).apply()
    }
}
