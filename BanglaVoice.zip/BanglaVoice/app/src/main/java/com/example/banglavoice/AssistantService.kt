package com.example.banglavoice

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.graphics.pdf.PdfDocument
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max

/**
 * The "hands and eyes": looks at the screen (element list + screenshot), asks Gemini for the next
 * actions, performs them, and repeats until the goal is done. Commands arrive from WakeService.
 * Besides tapping, it has direct tools: contacts, WhatsApp calls, email, gallery photos, PDF, share.
 */
class AssistantService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AssistantService? = null
        private const val MAX_STEPS = 40
        private const val WA_CHAT = "vnd.android.cursor.item/vnd.com.whatsapp.profile"
        private const val WA_VOICE = "vnd.android.cursor.item/vnd.com.whatsapp.voip.call"
        private const val WA_VIDEO = "vnd.android.cursor.item/vnd.com.whatsapp.video.call"
    }

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var wm: WindowManager? = null
    private var button: TextView? = null

    @Volatile private var busy = false
    @Volatile private var cancelled = false
    @Volatile private var teaching = false
    @Volatile private var confirming = false

    private var pendingConfirm: ((Boolean) -> Unit)? = null
    private var lastGoal = ""
    private var plan = ""
    private var failures = 0
    private val okLabels = ArrayList<String>()
    private val history = ArrayList<String>()
    private var lastNodes: List<AccessibilityNodeInfo> = emptyList()
    private var appsCache: List<String> = emptyList()

    // things the direct tools hand over to each other
    private var scratchPhotos: List<Uri> = emptyList()
    private var scratchPdf: File? = null

    // demonstration recording
    private val teachLog = ArrayList<String>()
    private var teachLabel = ""
    private var sdx = 0
    private var sdy = 0
    private var spkg = ""

    /** True while a task runs, a demonstration is recorded, or a yes/no answer is awaited. */
    fun engaged(): Boolean = busy || teaching || confirming

    // ---------- lifecycle ----------
    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        addOverlay()
        val micOk = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (!WakeService.running && micOk) {
            try {
                startForegroundService(Intent(this, WakeService::class.java))
            } catch (e: Exception) {
                toast("Hands-free chalu korte BanglaVoice app ekbar kholo")
            }
        }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        removeOverlay()
        instance = null
        return super.onUnbind(intent)
    }

    // ---------- floating status button ----------
    fun refreshButton() {
        val label = when {
            busy -> "⚙"
            teaching -> "📝"
            WakeService.session -> "🟢"
            WakeService.running -> "👂"
            else -> "🎤"
        }
        button?.text = label
    }

    private fun addOverlay() {
        val manager = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = manager
        val size = (52 * resources.displayMetrics.density).toInt()

        val tv = TextView(this).apply {
            textSize = 22f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xAA1565C0.toInt())
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 500
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) {
                        lp.x = startX + dx
                        lp.y = startY + dy
                        manager.updateViewLayout(tv, lp)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) onButtonTap()
            }
            true
        }
        manager.addView(tv, lp)
        button = tv
        refreshButton()
    }

    private fun removeOverlay() {
        button?.let { v -> runCatching { wm?.removeView(v) } }
        button = null
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    /** Tap = stop the current task, or wake / put to sleep the listening session. */
    private fun onButtonTap() {
        if (busy) {
            cancel()
            return
        }
        val w = WakeService.instance
        if (w == null) {
            toast("Hands-free chalu nei. BanglaVoice app kholo")
            return
        }
        w.toggleSession()
    }

    // ---------- called by WakeService (main thread) ----------
    fun runCommand(text: String) {
        if (busy) {
            toast("Ekta kaj cholche. 'Thamo' bolo")
            return
        }
        busy = true
        cancelled = false
        lastGoal = text
        plan = ""
        failures = 0
        okLabels.clear()
        history.clear()
        scratchPhotos = emptyList()
        scratchPdf = null
        refreshButton()
        toast("Shunlam: $text")
        io.execute {
            appsCache = installedApps()
            main.post { agentStep(text, 0) }
        }
    }

    fun cancel() {
        if (confirming) answer(false)
        if (busy) {
            cancelled = true
            toast("Thamchi...")
        }
    }

    fun answer(yes: Boolean) {
        val cb = pendingConfirm ?: return
        pendingConfirm = null
        confirming = false
        cb(yes)
    }

    /** The user corrected a mistake or explained how something should be done. */
    fun learn(text: String) {
        if (text.isBlank()) return
        Lessons.add(
            this,
            "User feedback: $text | Context: task='$lastGoal' last steps=${history.takeLast(6).joinToString(" | ")}"
        )
        toast("Shikhe nilam")
    }

    fun teachStart(label: String) {
        teaching = true
        teachLabel = label
        teachLog.clear()
        sdx = 0
        sdy = 0
        refreshButton()
        toast("Dekhao. Shesh hole 'Ara shesh' bolo")
    }

    fun teachEnd() {
        if (!teaching) return
        flushScroll()
        teaching = false
        refreshButton()
        if (teachLog.isEmpty()) {
            toast("Kichu dekhte pai ni")
            return
        }
        Lessons.add(
            this,
            "User demonstration (${teachLabel.ifBlank { "no title" }}): " + teachLog.joinToString("; ")
        )
        toast("Shikhe nilam (${teachLog.size} step)")
    }

    // ---------- watching a demonstration ----------
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (!teaching || e == null) return
        if (e.packageName?.toString() == packageName) return
        if (e.isPassword) return
        if (e.eventType != AccessibilityEvent.TYPE_VIEW_SCROLLED) flushScroll()
        val line = when (e.eventType) {
            AccessibilityEvent.TYPE_VIEW_CLICKED -> "click ${evDesc(e)}"
            AccessibilityEvent.TYPE_VIEW_LONG_CLICKED -> "long_click ${evDesc(e)}"
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> "typed \"${e.text.joinToString(" ").take(60)}\""
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> "opened ${e.packageName}/${e.className?.toString()?.substringAfterLast('.')}"
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                sdx += e.scrollDeltaX
                sdy += e.scrollDeltaY
                spkg = e.packageName?.toString() ?: ""
                null
            }
            else -> null
        }
        if (line != null && teachLog.size < 60) teachLog.add(line)
    }

    private fun flushScroll() {
        if (sdx != 0 || sdy != 0) {
            if (teachLog.size < 60) {
                teachLog.add("scroll in $spkg total dx=$sdx dy=$sdy (positive dy = moved further down the page)")
            }
            sdx = 0
            sdy = 0
        }
    }

    private fun evDesc(e: AccessibilityEvent): String {
        val t = e.text.joinToString(" ").take(60)
        val d = (e.contentDescription?.toString() ?: "").take(60)
        val cls = e.className?.toString()?.substringAfterLast('.') ?: ""
        val sb = StringBuilder("app=${e.packageName} $cls")
        if (t.isNotEmpty()) sb.append(" text=\"").append(t).append("\"")
        if (d.isNotEmpty()) sb.append(" desc=\"").append(d).append("\"")
        val src = e.source
        if (src != null) {
            val r = Rect()
            src.getBoundsInScreen(r)
            val dm = resources.displayMetrics
            sb.append(" @").append(r.centerX() * 1000 / dm.widthPixels)
                .append(",").append(r.centerY() * 1000 / dm.heightPixels)
        }
        return sb.toString()
    }

    // ---------- the agent loop ----------
    private fun agentStep(goal: String, step: Int) {
        if (cancelled) {
            finish("Thamlam")
            return
        }
        if (step >= MAX_STEPS) {
            finish("Onek step hoye gelo, thamlam")
            return
        }
        val screen = describeScreen()
        val hist = history.takeLast(14).joinToString("\n")
        val currentPlan = plan
        captureShot { shot ->
            io.execute {
                try {
                    val r = GeminiClient.next(
                        this, goal, appsCache, hist, currentPlan, screen, shot,
                        Lessons.relevant(this, goal), Lessons.relevantSkills(this, goal)
                    )
                    main.post { applyStep(goal, step, r) }
                } catch (e: Exception) {
                    main.post { finish("Error: ${e.message}") }
                }
            }
        }
    }

    private fun applyStep(goal: String, step: Int, r: Step) {
        if (cancelled) {
            finish("Thamlam")
            return
        }
        if (r.plan.isNotBlank()) plan = r.plan
        if (r.say.isNotBlank()) toast(r.say)
        if (r.done || r.actions.isEmpty()) {
            if (failures == 0 && okLabels.size >= 2) {
                Lessons.addSkill(this, lastGoal, okLabels.joinToString(" > "))
            }
            finish(null)
            return
        }
        if (r.risky) {
            confirm(r.say.ifBlank { r.actions[0].optString("type") }) { yes ->
                if (yes) runBatch(goal, step, r.actions, 0) else finish("Cancel korlam")
            }
        } else {
            runBatch(goal, step, r.actions, 0)
        }
    }

    /** Runs the actions one after another, stopping at the first failure. */
    private fun runBatch(goal: String, step: Int, actions: List<JSONObject>, i: Int) {
        if (cancelled) {
            finish("Thamlam")
            return
        }
        if (i >= actions.size) {
            main.postDelayed({ agentStep(goal, step + 1) }, 500)
            return
        }
        val a = actions[i]
        val label = skillLabel(a)
        perform(a) { ok, note ->
            val extra = if (note.isNullOrBlank()) "" else ": $note"
            if (ok) {
                okLabels.add(label)
                history.add("${history.size + 1}. $label -> ok$extra")
                main.postDelayed({ runBatch(goal, step, actions, i + 1) }, delayFor(a))
            } else {
                failures++
                history.add("${history.size + 1}. $a -> FAILED$extra")
                main.postDelayed({ agentStep(goal, step + 1) }, 500)
            }
        }
    }

    private fun delayFor(a: JSONObject): Long = when (a.optString("type")) {
        "wait" -> a.optLong("ms", 1000).coerceIn(200, 5000)
        "open_app", "open_url", "open_settings", "whatsapp_call", "whatsapp_chat",
        "compose_email", "share", "dial" -> 1800L
        "type", "scroll", "find_contact", "query_photos", "make_pdf" -> 500L
        else -> 900L
    }

    /** A short, id-free description of an action, for the history and for saved skills. */
    private fun skillLabel(a: JSONObject): String {
        val t = a.optString("type")
        val n = lastNodes.getOrNull(a.optInt("id", -1))
        val target = n?.let { (it.text ?: it.contentDescription)?.toString()?.take(40) }
        return when {
            target != null -> "$t '$target'"
            a.has("app") -> "$t ${a.optString("app")}"
            a.has("name") -> "$t ${a.optString("name")}"
            a.has("text") -> "$t \"${a.optString("text").take(40)}\""
            a.has("what") -> "$t ${a.optString("what")} ${a.optString("app")}"
            else -> t
        }
    }

    private fun finish(msg: String?) {
        busy = false
        cancelled = false
        if (!msg.isNullOrBlank()) toast(msg)
        refreshButton()
    }

    /** Asks by voice before risky actions. No clear "yes" within 25 s counts as "no". */
    private fun confirm(question: String, cb: (Boolean) -> Unit) {
        toast("Confirm: $question. 'Hya' ba 'na' bolo")
        pendingConfirm = cb
        confirming = true
        main.postDelayed({
            if (pendingConfirm === cb) {
                pendingConfirm = null
                confirming = false
                cb(false)
            }
        }, 25000)
    }

    // ---------- eyes ----------
    private fun describeScreen(): String {
        val dm = resources.displayMetrics
        val w = dm.widthPixels
        val h = dm.heightPixels
        val root = rootInActiveWindow
        if (root == null) {
            lastNodes = emptyList()
            return "(no accessible window: phone may be off, locked, or the screen is protected)"
        }
        val nodes = ArrayList<AccessibilityNodeInfo>()
        val sb = StringBuilder("app=${root.packageName}\n")

        fun walk(n: AccessibilityNodeInfo) {
            if (nodes.size >= 120) return
            if (n.isVisibleToUser) {
                val t = if (n.isPassword) "" else (n.text?.toString() ?: "").take(60)
                val d = (n.contentDescription?.toString() ?: "").take(60)
                if (n.isClickable || n.isEditable || n.isScrollable || n.isCheckable || t.isNotEmpty() || d.isNotEmpty()) {
                    val r = Rect()
                    n.getBoundsInScreen(r)
                    sb.append("[").append(nodes.size).append("] ")
                    sb.append(n.className?.toString()?.substringAfterLast('.') ?: "")
                    if (t.isNotEmpty()) sb.append(" text=\"").append(t).append("\"")
                    if (d.isNotEmpty()) sb.append(" desc=\"").append(d).append("\"")
                    if (n.isClickable) sb.append(" click")
                    if (n.isLongClickable) sb.append(" long")
                    if (n.isEditable) sb.append(" edit")
                    if (n.isScrollable) sb.append(" scroll")
                    if (n.isCheckable) sb.append(if (n.isChecked) " checked" else " unchecked")
                    if (n.isPassword) sb.append(" password")
                    sb.append(" @").append(r.centerX() * 1000 / w).append(",").append(r.centerY() * 1000 / h).append("\n")
                    nodes.add(n)
                }
            }
            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                walk(c)
            }
        }
        walk(root)
        lastNodes = nodes
        return sb.toString()
    }

    /** Screenshot as base64 JPEG (longest side 1000 px), or null if it cannot be taken. */
    private fun captureShot(cb: (String?) -> Unit) {
        if (Build.VERSION.SDK_INT < 30) {
            cb(null)
            return
        }
        try {
            takeScreenshot(
                Display.DEFAULT_DISPLAY, mainExecutor,
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                        io.execute {
                            val b64 = try { encodeShot(result) } catch (e: Exception) { null }
                            main.post { cb(b64) }
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        cb(null)
                    }
                }
            )
        } catch (e: Exception) {
            cb(null)
        }
    }

    private fun encodeShot(result: AccessibilityService.ScreenshotResult): String? {
        val hb = result.hardwareBuffer
        val hw = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
        if (hw == null) {
            hb.close()
            return null
        }
        val soft = hw.copy(Bitmap.Config.ARGB_8888, false)
        hw.recycle()
        hb.close()
        if (soft == null) return null
        val scale = 1000f / max(soft.width, soft.height)
        val small = if (scale < 1f) {
            Bitmap.createScaledBitmap(soft, (soft.width * scale).toInt(), (soft.height * scale).toInt(), true)
        } else {
            soft
        }
        val out = ByteArrayOutputStream()
        small.compress(Bitmap.CompressFormat.JPEG, 65, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    private fun installedApps(): List<String> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { it.loadLabel(pm).toString() }
            .distinct().sorted().take(250)
    }

    // ---------- hands: dispatch ----------
    private fun result(block: () -> Pair<Boolean, String?>): Pair<Boolean, String?> =
        try { block() } catch (e: Exception) { Pair(false, "error: ${e.message}") }

    private fun perform(a: JSONObject, done: (Boolean, String?) -> Unit) {
        when (a.optString("type")) {
            "find_contact" -> {
                val r = result { findContact(a.optString("name")) }
                done(r.first, r.second)
            }
            "whatsapp_call" -> {
                val mime = if (a.optBoolean("video", false)) WA_VIDEO else WA_VOICE
                val r = result { whatsappAction(a.optString("name"), mime) }
                done(r.first, r.second)
            }
            "whatsapp_chat" -> {
                val r = result { whatsappAction(a.optString("name"), WA_CHAT) }
                done(r.first, r.second)
            }
            "compose_email" -> {
                val r = result { composeEmail(a.optString("to"), a.optString("subject"), a.optString("body")) }
                done(r.first, r.second)
            }
            "query_photos" -> {
                val r = result { queryPhotos(a.optInt("count", 5), a.optString("folder"), a.optInt("minutes", 0)) }
                done(r.first, r.second)
            }
            "make_pdf" -> io.execute {
                val r = result { makePdf(a.optString("name")) }
                main.post { done(r.first, r.second) }
            }
            "share" -> {
                val r = result { share(a.optString("what", "photos"), a.optString("app"), a.optString("text")) }
                done(r.first, r.second)
            }
            else -> {
                val ok = try { performSimple(a) } catch (e: Exception) { false }
                done(ok, null)
            }
        }
    }

    private fun performSimple(a: JSONObject): Boolean = when (a.optString("type")) {
        "open_app" -> openApp(a.optString("app"))
        "open_settings" -> openSettings(a.optString("panel"))
        "open_url" -> openUrl(a.optString("url"))
        "dial" -> dial(a.optString("number"))
        "click" -> clickNode(node(a.optInt("id", -1)))
        "click_text" -> clickText(a.optString("text"))
        "long_press" -> node(a.optInt("id", -1))?.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK) ?: false
        "tap" -> tapNorm(a.optDouble("x", -1.0), a.optDouble("y", -1.0))
        "type" -> typeText(a.optInt("id", -1), a.optString("text"))
        "enter" -> pressEnter(a.optInt("id", -1))
        "scroll" -> scroll(a.optString("direction", "down"), a.optInt("id", -1))
        "swipe" -> swipe(a.optString("direction", "up"))
        "screen_on" -> screenOn()
        "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
        "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
        "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
        "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
        "quick_settings" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
        "lock" -> performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        "screenshot" -> performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
        "wait" -> true
        else -> false
    }

    private fun has(permission: String) = checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED

    // ---------- hands: direct tools ----------
    private fun findContact(name: String): Pair<Boolean, String?> {
        if (!has(Manifest.permission.READ_CONTACTS)) return Pair(false, "Contacts permission nei (BanglaVoice app e dao)")
        val q = name.trim()
        if (q.isEmpty()) return Pair(false, "name khali")
        val phone = ContactsContract.CommonDataKinds.Phone
        val c = contentResolver.query(
            phone.CONTENT_URI,
            arrayOf(phone.DISPLAY_NAME, phone.NUMBER),
            "${phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$q%"),
            null
        ) ?: return Pair(false, "contacts query hoy ni")
        val found = LinkedHashSet<String>()
        c.use {
            while (it.moveToNext() && found.size < 6) found.add("${it.getString(0)}: ${it.getString(1)}")
        }
        return if (found.isEmpty()) Pair(true, "'$q' nam e kono contact pai ni") else Pair(true, found.joinToString(" | "))
    }

    /** Opens a WhatsApp chat / voice call / video call through the contact's WhatsApp data row. */
    private fun whatsappAction(name: String, mime: String): Pair<Boolean, String?> {
        if (!has(Manifest.permission.READ_CONTACTS)) return Pair(false, "Contacts permission nei (BanglaVoice app e dao)")
        val q = name.trim()
        if (q.isEmpty()) return Pair(false, "name khali")
        val c = contentResolver.query(
            ContactsContract.Data.CONTENT_URI,
            arrayOf(ContactsContract.Data._ID, ContactsContract.Data.DISPLAY_NAME),
            "${ContactsContract.Data.MIMETYPE} = ? AND ${ContactsContract.Data.DISPLAY_NAME} LIKE ?",
            arrayOf(mime, "%$q%"),
            null
        ) ?: return Pair(false, "contacts query hoy ni")
        var id = -1L
        var shown = ""
        c.use {
            var best = Int.MAX_VALUE
            while (it.moveToNext()) {
                val nm = it.getString(1) ?: ""
                val score = if (nm.equals(q, ignoreCase = true)) 0 else nm.length - q.length + 1
                if (score < best) {
                    best = score
                    id = it.getLong(0)
                    shown = nm
                }
            }
        }
        if (id < 0) return Pair(false, "'$q' er WhatsApp entry pai ni. Contact er nam thik moto lekho, na hole WhatsApp e search kore koro")
        for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            try {
                val i = Intent(Intent.ACTION_VIEW)
                    .setDataAndType(Uri.parse("content://com.android.contacts/data/$id"), mime)
                    .setPackage(pkg)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
                return Pair(true, "$shown er jonno WhatsApp khola")
            } catch (e: Exception) {
                // try the next WhatsApp package
            }
        }
        return Pair(false, "WhatsApp khola jay ni")
    }

    private fun composeEmail(to: String, subject: String, body: String): Pair<Boolean, String?> {
        fun mail(pkg: String?) = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + Uri.encode(to))).apply {
            if (to.isNotBlank()) putExtra(Intent.EXTRA_EMAIL, arrayOf(to))
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, body)
            if (pkg != null) setPackage(pkg)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            startActivity(mail("com.google.android.gm"))
            Pair(true, "Gmail e mail ready, Send chapte hobe")
        } catch (e: Exception) {
            try {
                startActivity(mail(null))
                Pair(true, "mail app e mail ready, Send chapte hobe")
            } catch (e2: Exception) {
                Pair(false, "mail app pai ni")
            }
        }
    }

    private fun queryPhotos(count: Int, folder: String, minutes: Int): Pair<Boolean, String?> {
        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
        if (!has(perm)) return Pair(false, "Photo permission nei (BanglaVoice app e dao, 'Allow all')")
        val media = MediaStore.Images.Media
        val sel = StringBuilder("1=1")
        val args = ArrayList<String>()
        if (folder.isNotBlank() && Build.VERSION.SDK_INT >= 29) {
            sel.append(" AND ${media.RELATIVE_PATH} LIKE ?")
            args.add("%$folder%")
        }
        if (minutes > 0) {
            sel.append(" AND ${media.DATE_ADDED} >= ?")
            args.add((System.currentTimeMillis() / 1000 - minutes * 60L).toString())
        }
        val c = contentResolver.query(
            media.EXTERNAL_CONTENT_URI,
            arrayOf(media._ID, media.DISPLAY_NAME),
            sel.toString(),
            args.toTypedArray(),
            "${media.DATE_ADDED} DESC"
        ) ?: return Pair(false, "gallery query hoy ni")
        val limit = count.coerceIn(1, 40)
        val uris = ArrayList<Uri>()
        val names = ArrayList<String>()
        c.use {
            while (it.moveToNext() && uris.size < limit) {
                uris.add(ContentUris.withAppendedId(media.EXTERNAL_CONTENT_URI, it.getLong(0)))
                names.add(it.getString(1) ?: "")
            }
        }
        scratchPhotos = uris
        return if (uris.isEmpty()) {
            Pair(false, "kono photo pai ni")
        } else {
            Pair(true, "${uris.size} ta photo ready: ${names.take(5).joinToString(", ")}")
        }
    }

    private fun decodeScaled(uri: Uri, maxSide: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0) return null
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > maxSide * 2) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
        val orientation = try {
            contentResolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }
        val deg = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (deg != 0f) {
            val m = Matrix().apply { postRotate(deg) }
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        return bmp
    }

    /** Builds an A4 PDF, one photo per page, from the photos picked by query_photos. */
    private fun makePdf(name: String): Pair<Boolean, String?> {
        val photos = scratchPhotos
        if (photos.isEmpty()) return Pair(false, "age query_photos koro")
        val doc = PdfDocument()
        try {
            var pageNo = 0
            for (uri in photos) {
                val bmp = decodeScaled(uri, 1600) ?: continue
                pageNo++
                val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create())
                val box = RectF(24f, 24f, 571f, 818f)
                val s = minOf(box.width() / bmp.width, box.height() / bmp.height)
                val w = bmp.width * s
                val h = bmp.height * s
                val l = box.left + (box.width() - w) / 2
                val t = box.top + (box.height() - h) / 2
                page.canvas.drawBitmap(bmp, null, RectF(l, t, l + w, t + h), null)
                doc.finishPage(page)
                bmp.recycle()
            }
            if (pageNo == 0) return Pair(false, "photo porte pari ni")
            val dir = File(cacheDir, "share")
            dir.mkdirs()
            val safe = name.ifBlank { "photos" }.replace(Regex("[^A-Za-z0-9_-]"), "_")
            val f = File(dir, "$safe.pdf")
            FileOutputStream(f).use { doc.writeTo(it) }
            scratchPdf = f
            return Pair(true, "PDF ready: ${f.name} ($pageNo page)")
        } finally {
            doc.close()
        }
    }

    private fun packageForApp(label: String): String? {
        val n = label.trim().lowercase()
        if (n.isEmpty()) return null
        val pm = packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = list.firstOrNull { it.loadLabel(pm).toString().lowercase() == n }
            ?: list.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) }
        return hit?.activityInfo?.packageName
    }

    private fun share(what: String, app: String, text: String): Pair<Boolean, String?> {
        val pkg = packageForApp(app)
        val intent: Intent
        if (what == "pdf") {
            val f = scratchPdf ?: return Pair(false, "age make_pdf koro")
            val uri = FileProvider.getUriForFile(this, "$packageName.files", f)
            intent = Intent(Intent.ACTION_SEND).setType("application/pdf").putExtra(Intent.EXTRA_STREAM, uri)
        } else {
            val ph = scratchPhotos
            if (ph.isEmpty()) return Pair(false, "age query_photos koro")
            intent = if (ph.size == 1) {
                Intent(Intent.ACTION_SEND).setType("image/*").putExtra(Intent.EXTRA_STREAM, ph[0])
            } else {
                Intent(Intent.ACTION_SEND_MULTIPLE).setType("image/*")
                    .putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(ph))
            }
        }
        if (text.isNotBlank()) intent.putExtra(Intent.EXTRA_TEXT, text)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            if (pkg != null) {
                intent.setPackage(pkg)
                startActivity(intent)
            } else {
                startActivity(Intent.createChooser(intent, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            Pair(true, "share sheet khola" + if (pkg != null) " ($pkg)" else "")
        } catch (e: Exception) {
            Pair(false, "share hoy ni: ${e.message}")
        }
    }

    // ---------- hands: screen actions ----------
    private fun node(id: Int): AccessibilityNodeInfo? {
        val n = lastNodes.getOrNull(id) ?: return null
        n.refresh()
        return n
    }

    private fun openApp(name: String): Boolean {
        val n = name.trim().lowercase()
        if (n.isEmpty()) return false
        val pm = packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = list.firstOrNull { it.loadLabel(pm).toString().lowercase() == n }
            ?: list.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) }
            ?: return false
        val launch = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launch)
        return true
    }

    private fun openSettings(panel: String): Boolean {
        val action = when (panel) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }

    private fun openUrl(url: String): Boolean {
        if (!url.startsWith("https://") && !url.startsWith("http://")) return false
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }

    /** Opens the dialer with the number filled in. You still press the call button (safer). */
    private fun dial(number: String): Boolean {
        if (number.isBlank()) return false
        startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }

    private fun clickNode(n: AccessibilityNodeInfo?): Boolean {
        if (n == null) return false
        var cur: AccessibilityNodeInfo? = n
        while (cur != null && !cur.isClickable) cur = cur.parent
        if (cur != null && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        val r = Rect()
        n.getBoundsInScreen(r)
        return tap(r.centerX(), r.centerY())
    }

    private fun clickText(text: String): Boolean {
        if (text.isBlank()) return false
        val root = rootInActiveWindow ?: return false
        for (n in root.findAccessibilityNodeInfosByText(text)) {
            var cur: AccessibilityNodeInfo? = n
            while (cur != null && !cur.isClickable) cur = cur.parent
            if (cur != null && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        return false
    }

    /** Replaces the text of the given / focused / first editable input. Never touches password fields. */
    private fun typeText(id: Int, text: String): Boolean {
        val root = rootInActiveWindow
        val target = (if (id >= 0) node(id) else null)
            ?: root?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: root?.let { r -> findNode(r) { it.isEditable } }
            ?: return false
        if (target.isPassword) {
            toast("Password field e likhbo na")
            return false
        }
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun pressEnter(id: Int): Boolean {
        if (Build.VERSION.SDK_INT < 30) return false
        val target = (if (id >= 0) node(id) else null)
            ?: rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: return false
        return target.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
    }

    /**
     * Scrolls. With an element id it uses that element's own up/down/left/right scroll action.
     * Without one it swipes a finger vertically (or horizontally) across the middle of the screen,
     * which works the same in every app (feeds, lists, pages).
     */
    private fun scroll(direction: String, id: Int): Boolean {
        if (id >= 0) {
            val n = node(id)
            if (n != null) {
                val act = when (direction) {
                    "up" -> AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_UP
                    "left" -> AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_LEFT
                    "right" -> AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_RIGHT
                    else -> AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN
                }
                if (n.performAction(act.id)) return true
            }
        }
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        return when (direction) {
            "up" -> gesture(w / 2, h * 0.30f, w / 2, h * 0.72f, 350)
            "left" -> gesture(w * 0.25f, h / 2, w * 0.75f, h / 2, 350)
            "right" -> gesture(w * 0.75f, h / 2, w * 0.25f, h / 2, 350)
            else -> gesture(w / 2, h * 0.72f, w / 2, h * 0.30f, 350) // down: finger moves up
        }
    }

    /** Raw finger swipe across the screen. "up" = finger moves up. */
    private fun swipe(direction: String): Boolean {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        return when (direction) {
            "up" -> gesture(w / 2, h * 0.9f, w / 2, h * 0.3f, 300)
            "down" -> gesture(w / 2, h * 0.25f, w / 2, h * 0.75f, 300)
            "left" -> gesture(w * 0.8f, h / 2, w * 0.2f, h / 2, 300)
            else -> gesture(w * 0.2f, h / 2, w * 0.8f, h / 2, 300)
        }
    }

    private fun tapNorm(x: Double, y: Double): Boolean {
        if (x < 0 || y < 0) return false
        val dm = resources.displayMetrics
        return tap((x / 1000.0 * dm.widthPixels).toInt(), (y / 1000.0 * dm.heightPixels).toInt())
    }

    private fun tap(x: Int, y: Int): Boolean = gesture(x.toFloat(), y.toFloat(), x.toFloat(), y.toFloat(), 60)

    private fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long): Boolean {
        val path = Path().apply {
            moveTo(x1, y1)
            if (x1 != x2 || y1 != y2) lineTo(x2, y2)
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, ms))
            .build()
        return dispatchGesture(g, null, null)
    }

    /** Turns the screen on. If Face Unlock is set up, looking at the phone unlocks it. */
    @Suppress("DEPRECATION")
    private fun screenOn(): Boolean {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        val wl = pm.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
            "BanglaVoice:wake"
        )
        wl.acquire(5000)
        return true
    }

    private fun findNode(n: AccessibilityNodeInfo, match: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (match(n)) return n
        for (i in 0 until n.childCount) {
            val child = n.getChild(i) ?: continue
            findNode(child, match)?.let { return it }
        }
        return null
    }
}
