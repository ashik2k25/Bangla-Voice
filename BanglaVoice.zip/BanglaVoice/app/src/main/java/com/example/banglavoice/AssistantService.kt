package com.example.banglavoice

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.util.concurrent.Executors
import kotlin.math.abs

class AssistantService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AssistantService? = null
        private val RETRY = setOf("click_text", "type_text", "scroll")
    }

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var wm: WindowManager? = null
    private var button: TextView? = null
    private var recognizer: SpeechRecognizer? = null
    private var listening = false

    // ---------- lifecycle ----------
    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        addOverlay()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        removeOverlay()
        recognizer?.destroy()
        recognizer = null
        instance = null
        return super.onUnbind(intent)
    }

    // ---------- floating mic button ----------
    private fun addOverlay() {
        val manager = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = manager
        val size = (56 * resources.displayMetrics.density).toInt()

        val tv = TextView(this).apply {
            text = "🎤"
            textSize = 24f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xCC1565C0.toInt())
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 500
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) {
                        lp.x = startX + dx
                        lp.y = startY + dy
                        manager.updateViewLayout(tv, lp)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) toggleListening()
            }
            true
        }
        manager.addView(tv, lp)
        button = tv
    }

    private fun removeOverlay() {
        button?.let { v -> runCatching { wm?.removeView(v) } }
        button = null
    }

    private fun setButton(label: String) {
        button?.text = label
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    // ---------- speech ----------
    private fun toggleListening() {
        if (listening) {
            recognizer?.stopListening()
        } else {
            startListening()
        }
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("Mic permission dao (BanglaVoice app kholo)")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("Ei phone e speech recognition nei")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(listener)
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.language(this@AssistantService))
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        listening = true
        setButton("⏺")
        recognizer?.startListening(intent)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            listening = false
            setButton("🎤")
            toast("Shunte pai ni (code $error)")
        }

        override fun onResults(results: Bundle?) {
            listening = false
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (text.isNullOrBlank()) {
                setButton("🎤")
                toast("Kichu shuni ni")
            } else {
                handleSpeech(text)
            }
        }
    }

    // ---------- brain ----------
    private fun installedApps(): List<String> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { it.loadLabel(pm).toString() }
            .distinct().sorted().take(250)
    }

    private fun handleSpeech(text: String) {
        toast("Shunlam: $text")
        setButton("…")
        io.execute {
            try {
                val plan = GeminiClient.plan(this, text, installedApps())
                main.post {
                    if (plan.say.isNotBlank()) toast(plan.say)
                    runActions(plan.actions, 0, 0)
                }
            } catch (e: Exception) {
                main.post {
                    toast("Error: ${e.message}")
                    setButton("🎤")
                }
            }
        }
    }

    // ---------- hands ----------
    private fun runActions(actions: List<JSONObject>, i: Int, attempt: Int) {
        if (i >= actions.size) {
            setButton("🎤")
            return
        }
        val a = actions[i]
        val type = a.optString("type")
        val ok = try { perform(a) } catch (e: Exception) { false }
        if (!ok) {
            if (attempt < 2 && type in RETRY) {
                main.postDelayed({ runActions(actions, i, attempt + 1) }, 800)
                return
            }
            toast("Step ${i + 1} ($type) hoy ni, thamlam")
            setButton("🎤")
            return
        }
        val wait = if (type == "wait") a.optLong("ms", 1000).coerceIn(200, 5000) else 900L
        main.postDelayed({ runActions(actions, i + 1, 0) }, wait)
    }

    private fun perform(a: JSONObject): Boolean = when (a.optString("type")) {
        "open_app" -> openApp(a.optString("app"))
        "open_settings" -> openSettings(a.optString("panel"))
        "open_url" -> openUrl(a.optString("url"))
        "dial" -> dial(a.optString("number"))
        "click_text" -> clickText(a.optString("text"))
        "type_text" -> typeText(a.optString("text"))
        "scroll" -> scroll(a.optString("direction", "down"))
        "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
        "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
        "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
        "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
        "quick_settings" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
        "lock" -> performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        "screenshot" -> performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
        "wait" -> true
        else -> false
    }

    private fun openApp(name: String): Boolean {
        val n = name.trim().lowercase()
        if (n.isEmpty()) return false
        val pm = packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = list.firstOrNull { it.loadLabel(pm).toString().lowercase() == n }
            ?: list.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) }
            ?: return false
        val launch = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launch)
        return true
    }

    private fun openSettings(panel: String): Boolean {
        val action = when (panel) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }

    private fun openUrl(url: String): Boolean {
        if (!url.startsWith("https://") && !url.startsWith("http://")) return false
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }

    /** Opens the dialer with the number filled in. You still press the call button (safer). */
    private fun dial(number: String): Boolean {
        if (number.isBlank()) return false
        startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }

    private fun clickText(text: String): Boolean {
        if (text.isBlank()) return false
        val root = rootInActiveWindow ?: return false
        for (n in root.findAccessibilityNodeInfosByText(text)) {
            var cur: AccessibilityNodeInfo? = n
            while (cur != null && !cur.isClickable) cur = cur.parent
            if (cur != null && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        return false
    }

    /** Replaces the text of the focused input (or the first editable field on screen). */
    private fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val target = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findNode(root) { it.isEditable } ?: return false
        if (target.isPassword) {
            toast("Password field e likhbo na")
            return false
        }
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun scroll(direction: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findNode(root) { it.isScrollable } ?: return false
        val act = if (direction == "up" || direction == "left") {
            AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        } else {
            AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        }
        return node.performAction(act)
    }

    private fun findNode(n: AccessibilityNodeInfo, match: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (match(n)) return n
        for (i in 0 until n.childCount) {
            val child = n.getChild(i) ?: continue
            findNode(child, match)?.let { return it }
        }
        return null
    }
}
