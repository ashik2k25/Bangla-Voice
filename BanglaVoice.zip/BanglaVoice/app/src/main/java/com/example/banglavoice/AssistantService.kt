package com.example.banglavoice

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.util.Base64
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max

/**
 * The "hands and eyes": looks at the screen (element list + screenshot), asks Gemini for the next
 * step, performs it, and repeats until the goal is done. Commands arrive from WakeService.
 */
class AssistantService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AssistantService? = null
        private const val MAX_STEPS = 20
    }

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var wm: WindowManager? = null
    private var button: TextView? = null

    @Volatile private var busy = false
    @Volatile private var cancelled = false
    @Volatile private var teaching = false
    @Volatile private var confirming = false

    private var pendingConfirm: ((Boolean) -> Unit)? = null
    private var lastGoal = ""
    private val history = ArrayList<String>()
    private var lastNodes: List<AccessibilityNodeInfo> = emptyList()
    private var appsCache: List<String> = emptyList()

    // demonstration recording
    private val teachLog = ArrayList<String>()
    private var teachLabel = ""
    private var sdx = 0
    private var sdy = 0
    private var spkg = ""

    /** True while a task runs, a demonstration is recorded, or a yes/no answer is awaited. */
    fun engaged(): Boolean = busy || teaching || confirming

    // ---------- lifecycle ----------
    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        addOverlay()
        val micOk = checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
        if (!WakeService.running && micOk) {
            try {
                startForegroundService(Intent(this, WakeService::class.java))
            } catch (e: Exception) {
                toast("Hands-free chalu korte BanglaVoice app ekbar kholo")
            }
        }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        removeOverlay()
        instance = null
        return super.onUnbind(intent)
    }

    // ---------- floating status button ----------
    fun refreshButton() {
        val label = when {
            busy -> "⚙"
            teaching -> "📝"
            WakeService.session -> "🟢"
            WakeService.running -> "👂"
            else -> "🎤"
        }
        button?.text = label
    }

    private fun addOverlay() {
        val manager = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = manager
        val size = (52 * resources.displayMetrics.density).toInt()

        val tv = TextView(this).apply {
            textSize = 22f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xAA1565C0.toInt())
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 500
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) {
                        lp.x = startX + dx
                        lp.y = startY + dy
                        manager.updateViewLayout(tv, lp)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) onButtonTap()
            }
            true
        }
        manager.addView(tv, lp)
        button = tv
        refreshButton()
    }

    private fun removeOverlay() {
        button?.let { v -> runCatching { wm?.removeView(v) } }
        button = null
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    /** Tap = stop the current task, or wake / put to sleep the listening session. */
    private fun onButtonTap() {
        if (busy) {
            cancel()
            return
        }
        val w = WakeService.instance
        if (w == null) {
            toast("Hands-free chalu nei. BanglaVoice app kholo")
            return
        }
        w.toggleSession()
    }

    // ---------- called by WakeService (main thread) ----------
    fun runCommand(text: String) {
        if (busy) {
            toast("Ekta kaj cholche. 'Thamo' bolo")
            return
        }
        busy = true
        cancelled = false
        lastGoal = text
        history.clear()
        refreshButton()
        toast("Shunlam: $text")
        io.execute {
            appsCache = installedApps()
            main.post { agentStep(text, 0) }
        }
    }

    fun cancel() {
        if (confirming) answer(false)
        if (busy) {
            cancelled = true
            toast("Thamchi...")
        }
    }

    fun answer(yes: Boolean) {
        val cb = pendingConfirm ?: return
        pendingConfirm = null
        confirming = false
        cb(yes)
    }

    /** The user corrected a mistake or explained how something should be done. */
    fun learn(text: String) {
        if (text.isBlank()) return
        Lessons.add(
            this,
            "User feedback: $text | Context: task='$lastGoal' last steps=${history.takeLast(6).joinToString(" | ")}"
        )
        toast("Shikhe nilam")
    }

    fun teachStart(label: String) {
        teaching = true
        teachLabel = label
        teachLog.clear()
        sdx = 0
        sdy = 0
        refreshButton()
        toast("Dekhao. Shesh hole 'Ara shesh' bolo")
    }

    fun teachEnd() {
        if (!teaching) return
        flushScroll()
        teaching = false
        refreshButton()
        if (teachLog.isEmpty()) {
            toast("Kichu dekhte pai ni")
            return
        }
        Lessons.add(
            this,
            "User demonstration (${teachLabel.ifBlank { "no title" }}): " + teachLog.joinToString("; ")
        )
        toast("Shikhe nilam (${teachLog.size} step)")
    }

    // ---------- watching a demonstration ----------
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (!teaching || e == null) return
        if (e.packageName?.toString() == packageName) return
        if (e.isPassword) return
        if (e.eventType != AccessibilityEvent.TYPE_VIEW_SCROLLED) flushScroll()
        val line = when (e.eventType) {
            AccessibilityEvent.TYPE_VIEW_CLICKED -> "click ${evDesc(e)}"
            AccessibilityEvent.TYPE_VIEW_LONG_CLICKED -> "long_click ${evDesc(e)}"
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> "typed \"${e.text.joinToString(" ").take(60)}\""
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> "opened ${e.packageName}/${e.className?.toString()?.substringAfterLast('.')}"
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                sdx += e.scrollDeltaX
                sdy += e.scrollDeltaY
                spkg = e.packageName?.toString() ?: ""
                null
            }
            else -> null
        }
        if (line != null && teachLog.size < 60) teachLog.add(line)
    }

    private fun flushScroll() {
        if (sdx != 0 || sdy != 0) {
            if (teachLog.size < 60) {
                teachLog.add("scroll in $spkg total dx=$sdx dy=$sdy (positive dy = moved further down the page)")
            }
            sdx = 0
            sdy = 0
        }
    }

    private fun evDesc(e: AccessibilityEvent): String {
        val t = e.text.joinToString(" ").take(60)
        val d = (e.contentDescription?.toString() ?: "").take(60)
        val cls = e.className?.toString()?.substringAfterLast('.') ?: ""
        val sb = StringBuilder("app=${e.packageName} $cls")
        if (t.isNotEmpty()) sb.append(" text=\"").append(t).append("\"")
        if (d.isNotEmpty()) sb.append(" desc=\"").append(d).append("\"")
        val src = e.source
        if (src != null) {
            val r = Rect()
            src.getBoundsInScreen(r)
            val dm = resources.displayMetrics
            sb.append(" @").append(r.centerX() * 1000 / dm.widthPixels)
                .append(",").append(r.centerY() * 1000 / dm.heightPixels)
        }
        return sb.toString()
    }

    // ---------- the agent loop ----------
    private fun agentStep(goal: String, step: Int) {
        if (cancelled) {
            finish("Thamlam")
            return
        }
        if (step >= MAX_STEPS) {
            finish("Onek step hoye gelo, thamlam")
            return
        }
        val screen = describeScreen()
        val hist = history.takeLast(12).joinToString("\n")
        captureShot { shot ->
            io.execute {
                try {
                    val r = GeminiClient.next(this, goal, appsCache, hist, screen, shot, Lessons.relevant(this, goal))
                    main.post { applyStep(goal, step, r) }
                } catch (e: Exception) {
                    main.post { finish("Error: ${e.message}") }
                }
            }
        }
    }

    private fun applyStep(goal: String, step: Int, r: Step) {
        if (cancelled) {
            finish("Thamlam")
            return
        }
        if (r.say.isNotBlank()) toast(r.say)
        val a = r.action
        if (r.done || a == null) {
            finish(null)
            return
        }
        if (r.risky) {
            confirm(r.say.ifBlank { a.optString("type") }) { yes ->
                if (yes) execute(goal, step, a) else finish("Cancel korlam")
            }
        } else {
            execute(goal, step, a)
        }
    }

    private fun execute(goal: String, step: Int, a: JSONObject) {
        val type = a.optString("type")
        val ok = try { perform(a) } catch (e: Exception) { false }
        history.add("${step + 1}. $a -> ${if (ok) "ok" else "FAILED"}")
        val wait = if (type == "wait") a.optLong("ms", 1000).coerceIn(200, 5000) else 1300L
        main.postDelayed({ agentStep(goal, step + 1) }, wait)
    }

    private fun finish(msg: String?) {
        busy = false
        cancelled = false
        if (!msg.isNullOrBlank()) toast(msg)
        refreshButton()
    }

    /** Asks by voice before risky actions. No clear "yes" within 25 s counts as "no". */
    private fun confirm(question: String, cb: (Boolean) -> Unit) {
        toast("Confirm: $question. 'Hya' ba 'na' bolo")
        pendingConfirm = cb
        confirming = true
        main.postDelayed({
            if (pendingConfirm === cb) {
                pendingConfirm = null
                confirming = false
                cb(false)
            }
        }, 25000)
    }

    // ---------- eyes ----------
    private fun describeScreen(): String {
        val dm = resources.displayMetrics
        val w = dm.widthPixels
        val h = dm.heightPixels
        val root = rootInActiveWindow
        if (root == null) {
            lastNodes = emptyList()
            return "(no accessible window: phone may be off, locked, or the screen is protected)"
        }
        val nodes = ArrayList<AccessibilityNodeInfo>()
        val sb = StringBuilder("app=${root.packageName}\n")

        fun walk(n: AccessibilityNodeInfo) {
            if (nodes.size >= 120) return
            if (n.isVisibleToUser) {
                val t = if (n.isPassword) "" else (n.text?.toString() ?: "").take(60)
                val d = (n.contentDescription?.toString() ?: "").take(60)
                if (n.isClickable || n.isEditable || n.isScrollable || n.isCheckable || t.isNotEmpty() || d.isNotEmpty()) {
                    val r = Rect()
                    n.getBoundsInScreen(r)
                    sb.append("[").append(nodes.size).append("] ")
                    sb.append(n.className?.toString()?.substringAfterLast('.') ?: "")
                    if (t.isNotEmpty()) sb.append(" text=\"").append(t).append("\"")
                    if (d.isNotEmpty()) sb.append(" desc=\"").append(d).append("\"")
                    if (n.isClickable) sb.append(" click")
                    if (n.isLongClickable) sb.append(" long")
                    if (n.isEditable) sb.append(" edit")
                    if (n.isScrollable) sb.append(" scroll")
                    if (n.isCheckable) sb.append(if (n.isChecked) " checked" else " unchecked")
                    if (n.isPassword) sb.append(" password")
                    sb.append(" @").append(r.centerX() * 1000 / w).append(",").append(r.centerY() * 1000 / h).append("\n")
                    nodes.add(n)
                }
            }
            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                walk(c)
            }
        }
        walk(root)
        lastNodes = nodes
        return sb.toString()
    }

    /** Screenshot as base64 JPEG (longest side 1280 px), or null if it cannot be taken. */
    private fun captureShot(cb: (String?) -> Unit) {
        if (Build.VERSION.SDK_INT < 30) {
            cb(null)
            return
        }
        try {
            takeScreenshot(
                Display.DEFAULT_DISPLAY, mainExecutor,
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                        io.execute {
                            val b64 = try { encodeShot(result) } catch (e: Exception) { null }
                            main.post { cb(b64) }
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        cb(null)
                    }
                }
            )
        } catch (e: Exception) {
            cb(null)
        }
    }

    private fun encodeShot(result: AccessibilityService.ScreenshotResult): String? {
        val hb = result.hardwareBuffer
        val hw = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
        if (hw == null) {
            hb.close()
            return null
        }
        val soft = hw.copy(Bitmap.Config.ARGB_8888, false)
        hw.recycle()
        hb.close()
        if (soft == null) return null
        val scale = 1280f / max(soft.width, soft.height)
        val small = if (scale < 1f) {
            Bitmap.createScaledBitmap(soft, (soft.width * scale).toInt(), (soft.height * scale).toInt(), true)
        } else {
            soft
        }
        val out = ByteArrayOutputStream()
        small.compress(Bitmap.CompressFormat.JPEG, 70, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    private fun installedApps(): List<String> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { it.loadLabel(pm).toString() }
            .distinct().sorted().take(250)
    }

    // ---------- hands ----------
    private fun perform(a: JSONObject): Boolean = when (a.optString("type")) {
        "open_app" -> openApp(a.optString("app"))
        "open_settings" -> openSettings(a.optString("panel"))
        "open_url" -> openUrl(a.optString("url"))
        "dial" -> dial(a.optString("number"))
        "click" -> clickNode(node(a.optInt("id", -1)))
        "click_text" -> clickText(a.optString("text"))
        "long_press" -> node(a.optInt("id", -1))?.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK) ?: false
        "tap" -> tapNorm(a.optDouble("x", -1.0), a.optDouble("y", -1.0))
        "type" -> typeText(a.optInt("id", -1), a.optString("text"))
        "enter" -> pressEnter(a.optInt("id", -1))
        "scroll" -> scroll(a.optString("direction", "down"), a.optInt("id", -1))
        "swipe" -> swipe(a.optString("direction", "up"))
        "screen_on" -> screenOn()
        "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
        "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
        "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
        "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
        "quick_settings" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
        "lock" -> performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        "screenshot" -> performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
        "wait" -> true
        else -> false
    }

    private fun node(id: Int): AccessibilityNodeInfo? {
        val n = lastNodes.getOrNull(id) ?: return null
        n.refresh()
        return n
    }

    private fun openApp(name: String): Boolean {
        val n = name.trim().lowercase()
        if (n.isEmpty()) return false
        val pm = packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = list.firstOrNull { it.loadLabel(pm).toString().lowercase() == n }
            ?: list.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) }
            ?: return false
        val launch = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launch)
        return true
    }

    private fun openSettings(panel: String): Boolean {
        val action = when (panel) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }

    private fun openUrl(url: String): Boolean {
        if (!url.startsWith("https://") && !url.startsWith("http://")) return false
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }

    /** Opens the dialer with the number filled in. You still press the call button (safer). */
    private fun dial(number: String): Boolean {
        if (number.isBlank()) return false
        startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }

    private fun clickNode(n: AccessibilityNodeInfo?): Boolean {
        if (n == null) return false
        var cur: AccessibilityNodeInfo? = n
        while (cur != null && !cur.isClickable) cur = cur.parent
        if (cur != null && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        val r = Rect()
        n.getBoundsInScreen(r)
        return tap(r.centerX(), r.centerY())
    }

    private fun clickText(text: String): Boolean {
        if (text.isBlank()) return false
        val root = rootInActiveWindow ?: return false
        for (n in root.findAccessibilityNodeInfosByText(text)) {
            var cur: AccessibilityNodeInfo? = n
            while (cur != null && !cur.isClickable) cur = cur.parent
            if (cur != null && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        return false
    }

    /** Replaces the text of the given / focused / first editable input. Never touches password fields. */
    private fun typeText(id: Int, text: String): Boolean {
        val root = rootInActiveWindow
        val target = (if (id >= 0) node(id) else null)
            ?: root?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: root?.let { r -> findNode(r) { it.isEditable } }
            ?: return false
        if (target.isPassword) {
            toast("Password field e likhbo na")
            return false
        }
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun pressEnter(id: Int): Boolean {
        if (Build.VERSION.SDK_INT < 30) return false
        val target = (if (id >= 0) node(id) else null)
            ?: rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: return false
        return target.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
    }

    /**
     * Scrolls. With an element id it uses that element's own up/down/left/right scroll action.
     * Without one it swipes a finger vertically (or horizontally) across the middle of the screen,
     * which works the same in every app (feeds, lists, pages).
     */
    private fun scroll(direction: String, id: Int): Boolean {
        if (id >= 0) {
            val n = node(id)
            if (n != null) {
                val act = when (direction) {
                    "up" -> AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_UP
                    "left" -> AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_LEFT
                    "right" -> AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_RIGHT
                    else -> AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN
                }
                if (n.performAction(act.id)) return true
            }
        }
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        return when (direction) {
            "up" -> gesture(w / 2, h * 0.30f, w / 2, h * 0.72f, 350)
            "left" -> gesture(w * 0.25f, h / 2, w * 0.75f, h / 2, 350)
            "right" -> gesture(w * 0.75f, h / 2, w * 0.25f, h / 2, 350)
            else -> gesture(w / 2, h * 0.72f, w / 2, h * 0.30f, 350) // down: finger moves up
        }
    }

    /** Raw finger swipe across the screen. "up" = finger moves up. */
    private fun swipe(direction: String): Boolean {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        return when (direction) {
            "up" -> gesture(w / 2, h * 0.9f, w / 2, h * 0.3f, 300)
            "down" -> gesture(w / 2, h * 0.25f, w / 2, h * 0.75f, 300)
            "left" -> gesture(w * 0.8f, h / 2, w * 0.2f, h / 2, 300)
            else -> gesture(w * 0.2f, h / 2, w * 0.8f, h / 2, 300)
        }
    }

    private fun tapNorm(x: Double, y: Double): Boolean {
        if (x < 0 || y < 0) return false
        val dm = resources.displayMetrics
        return tap((x / 1000.0 * dm.widthPixels).toInt(), (y / 1000.0 * dm.heightPixels).toInt())
    }

    private fun tap(x: Int, y: Int): Boolean = gesture(x.toFloat(), y.toFloat(), x.toFloat(), y.toFloat(), 60)

    private fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long): Boolean {
        val path = Path().apply {
            moveTo(x1, y1)
            if (x1 != x2 || y1 != y2) lineTo(x2, y2)
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, ms))
            .build()
        return dispatchGesture(g, null, null)
    }

    /** Turns the screen on. If Face Unlock is set up, looking at the phone unlocks it. */
    @Suppress("DEPRECATION")
    private fun screenOn(): Boolean {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        val wl = pm.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
            "BanglaVoice:wake"
        )
        wl.acquire(5000)
        return true
    }

    private fun findNode(n: AccessibilityNodeInfo, match: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (match(n)) return n
        for (i in 0 until n.childCount) {
            val child = n.getChild(i) ?: continue
            findNode(child, match)?.let { return it }
        }
        return null
    }
}
