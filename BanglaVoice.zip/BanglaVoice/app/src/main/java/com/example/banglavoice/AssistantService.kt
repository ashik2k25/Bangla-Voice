package com.example.banglavoice

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.util.concurrent.Executors
import kotlin.math.abs

/**
 * The "hands": reads the screen, asks Gemini for the next step, performs it, repeats until done.
 * Triggered by the floating mic button or by WakeService (hands-free name).
 */
class AssistantService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AssistantService? = null
        private const val MAX_STEPS = 20
        private val YES = listOf("হ্যাঁ", "হ্যা", "হাঁ", "হা", "ঠিক", "করো", "yes", "ok", "okay", "ha")
        private val NO = listOf("না", "থামো", "no", "cancel", "stop")
    }

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var wm: WindowManager? = null
    private var button: TextView? = null
    private var recognizer: SpeechRecognizer? = null

    @Volatile private var listening = false
    @Volatile private var busy = false
    @Volatile private var cancelled = false
    @Volatile private var holdUntil = 0L

    private var heardCb: ((String?) -> Unit)? = null
    private val history = ArrayList<String>()
    private var lastNodes: List<AccessibilityNodeInfo> = emptyList()
    private var appsCache: List<String> = emptyList()

    /** True while listening, working, or just signalled; WakeService waits meanwhile. */
    fun engaged(): Boolean = listening || busy || System.currentTimeMillis() < holdUntil

    // ---------- lifecycle ----------
    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        addOverlay()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        removeOverlay()
        recognizer?.destroy()
        recognizer = null
        instance = null
        return super.onUnbind(intent)
    }

    // ---------- floating button ----------
    private fun idleLabel() = if (WakeService.running) "👂" else "🎤"

    fun refreshButton() {
        if (!engaged()) setButton(idleLabel())
    }

    private fun addOverlay() {
        val manager = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = manager
        val size = (56 * resources.displayMetrics.density).toInt()

        val tv = TextView(this).apply {
            text = idleLabel()
            textSize = 24f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xCC1565C0.toInt())
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 500
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) {
                        lp.x = startX + dx
                        lp.y = startY + dy
                        manager.updateViewLayout(tv, lp)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) onButtonTap()
            }
            true
        }
        manager.addView(tv, lp)
        button = tv
    }

    private fun removeOverlay() {
        button?.let { v -> runCatching { wm?.removeView(v) } }
        button = null
    }

    private fun setButton(label: String) {
        button?.text = label
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun onButtonTap() {
        if (busy) {
            cancelled = true
            toast("Thamchi...")
            return
        }
        if (listening) {
            recognizer?.stopListening()
            return
        }
        listenOnce { t -> if (!t.isNullOrBlank()) runCommand(t) }
    }

    /** Short beep so the user knows it is listening for the command. */
    fun signal() {
        holdUntil = System.currentTimeMillis() + 1800
        setButton("⏺")
        toast("Shunchi...")
        runCatching { ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80).startTone(ToneGenerator.TONE_PROP_BEEP, 120) }
    }

    // ---------- speech (one sentence) ----------
    fun listenOnce(cb: (String?) -> Unit) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("Mic permission dao (BanglaVoice app kholo)")
            cb(null)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("Ei phone e speech recognition nei")
            cb(null)
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(listener)
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.language(this@AssistantService))
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        heardCb = cb
        listening = true
        setButton("⏺")
        recognizer?.startListening(intent)
    }

    private fun finishListening(text: String?, error: Int) {
        listening = false
        val cb = heardCb
        heardCb = null
        if (text == null) {
            toast("Shunte pai ni (code $error)")
            if (!busy) setButton(idleLabel())
        }
        cb?.invoke(text)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            finishListening(null, error)
        }

        override fun onResults(results: Bundle?) {
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (text.isNullOrBlank()) finishListening(null, 0) else finishListening(text, 0)
        }
    }

    // ---------- the agent loop ----------
    fun runCommand(text: String) {
        if (busy) {
            toast("Ekta kaj cholche, button e tap kore thamao")
            return
        }
        busy = true
        cancelled = false
        history.clear()
        setButton("…")
        toast("Shunlam: $text")
        io.execute {
            appsCache = installedApps()
            main.post { agentStep(text, 0) }
        }
    }

    private fun agentStep(goal: String, step: Int) {
        if (cancelled) {
            finish("Thamlam")
            return
        }
        if (step >= MAX_STEPS) {
            finish("Onek step hoye gelo, thamlam")
            return
        }
        val screen = describeScreen()
        val hist = history.takeLast(12).joinToString("\n")
        io.execute {
            try {
                val r = GeminiClient.next(this, goal, appsCache, hist, screen)
                main.post { applyStep(goal, step, r) }
            } catch (e: Exception) {
                main.post { finish("Error: ${e.message}") }
            }
        }
    }

    private fun applyStep(goal: String, step: Int, r: Step) {
        if (cancelled) {
            finish("Thamlam")
            return
        }
        if (r.say.isNotBlank()) toast(r.say)
        val a = r.action
        if (r.done || a == null) {
            finish(null)
            return
        }
        if (r.risky) {
            confirm(r.say.ifBlank { a.optString("type") }) { yes ->
                if (yes) execute(goal, step, a) else finish("Cancel korlam")
            }
        } else {
            execute(goal, step, a)
        }
    }

    private fun execute(goal: String, step: Int, a: JSONObject) {
        val type = a.optString("type")
        val ok = try { perform(a) } catch (e: Exception) { false }
        history.add("${step + 1}. $a -> ${if (ok) "ok" else "FAILED"}")
        val wait = if (type == "wait") a.optLong("ms", 1000).coerceIn(200, 5000) else 1200L
        main.postDelayed({ agentStep(goal, step + 1) }, wait)
    }

    private fun finish(msg: String?) {
        busy = false
        cancelled = false
        if (!msg.isNullOrBlank()) toast(msg)
        setButton(idleLabel())
    }

    /** Asks the user by voice before risky actions. Anything unclear counts as "no". */
    private fun confirm(question: String, cb: (Boolean) -> Unit) {
        toast("Confirm: $question. 'hya' ba 'na' bolo")
        main.postDelayed({
            listenOnce { t ->
                val s = t?.lowercase() ?: ""
                val no = NO.any { s.contains(it) }
                val yes = !no && YES.any { s.contains(it) }
                cb(yes)
            }
        }, 1500)
    }

    // ---------- eyes ----------
    private fun describeScreen(): String {
        val dm = resources.displayMetrics
        val root = rootInActiveWindow
        if (root == null) {
            lastNodes = emptyList()
            return "screen ${dm.widthPixels}x${dm.heightPixels}; (no accessible window: phone may be off, locked, or the screen is protected)"
        }
        val nodes = ArrayList<AccessibilityNodeInfo>()
        val sb = StringBuilder("screen ${dm.widthPixels}x${dm.heightPixels}; app=${root.packageName}\n")

        fun walk(n: AccessibilityNodeInfo) {
            if (nodes.size >= 120) return
            if (n.isVisibleToUser) {
                val t = if (n.isPassword) "" else (n.text?.toString() ?: "").take(60)
                val d = (n.contentDescription?.toString() ?: "").take(60)
                if (n.isClickable || n.isEditable || n.isScrollable || n.isCheckable || t.isNotEmpty() || d.isNotEmpty()) {
                    val r = Rect()
                    n.getBoundsInScreen(r)
                    sb.append("[").append(nodes.size).append("] ")
                    sb.append(n.className?.toString()?.substringAfterLast('.') ?: "")
                    if (t.isNotEmpty()) sb.append(" text=\"").append(t).append("\"")
                    if (d.isNotEmpty()) sb.append(" desc=\"").append(d).append("\"")
                    if (n.isClickable) sb.append(" click")
                    if (n.isLongClickable) sb.append(" long")
                    if (n.isEditable) sb.append(" edit")
                    if (n.isScrollable) sb.append(" scroll")
                    if (n.isCheckable) sb.append(if (n.isChecked) " checked" else " unchecked")
                    if (n.isPassword) sb.append(" password")
                    sb.append(" @").append(r.centerX()).append(",").append(r.centerY()).append("\n")
                    nodes.add(n)
                }
            }
            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                walk(c)
            }
        }
        walk(root)
        lastNodes = nodes
        return sb.toString()
    }

    private fun installedApps(): List<String> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { it.loadLabel(pm).toString() }
            .distinct().sorted().take(250)
    }

    // ---------- hands ----------
    private fun perform(a: JSONObject): Boolean = when (a.optString("type")) {
        "open_app" -> openApp(a.optString("app"))
        "open_settings" -> openSettings(a.optString("panel"))
        "open_url" -> openUrl(a.optString("url"))
        "dial" -> dial(a.optString("number"))
        "click" -> clickNode(node(a.optInt("id", -1)))
        "click_text" -> clickText(a.optString("text"))
        "long_press" -> node(a.optInt("id", -1))?.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK) ?: false
        "tap" -> tap(a.optInt("x"), a.optInt("y"))
        "type" -> typeText(a.optInt("id", -1), a.optString("text"))
        "enter" -> pressEnter(a.optInt("id", -1))
        "scroll" -> scroll(a.optString("direction", "down"), a.optInt("id", -1))
        "swipe" -> swipe(a.optString("direction", "up"))
        "screen_on" -> screenOn()
        "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
        "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
        "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
        "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
        "quick_settings" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
        "lock" -> performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        "screenshot" -> performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
        "wait" -> true
        else -> false
    }

    private fun node(id: Int): AccessibilityNodeInfo? {
        val n = lastNodes.getOrNull(id) ?: return null
        n.refresh()
        return n
    }

    private fun openApp(name: String): Boolean {
        val n = name.trim().lowercase()
        if (n.isEmpty()) return false
        val pm = packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = list.firstOrNull { it.loadLabel(pm).toString().lowercase() == n }
            ?: list.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) }
            ?: return false
        val launch = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launch)
        return true
    }

    private fun openSettings(panel: String): Boolean {
        val action = when (panel) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }

    private fun openUrl(url: String): Boolean {
        if (!url.startsWith("https://") && !url.startsWith("http://")) return false
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }

    /** Opens the dialer with the number filled in. You still press the call button (safer). */
    private fun dial(number: String): Boolean {
        if (number.isBlank()) return false
        startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }

    private fun clickNode(n: AccessibilityNodeInfo?): Boolean {
        if (n == null) return false
        var cur: AccessibilityNodeInfo? = n
        while (cur != null && !cur.isClickable) cur = cur.parent
        if (cur != null && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        val r = Rect()
        n.getBoundsInScreen(r)
        return tap(r.centerX(), r.centerY())
    }

    private fun clickText(text: String): Boolean {
        if (text.isBlank()) return false
        val root = rootInActiveWindow ?: return false
        for (n in root.findAccessibilityNodeInfosByText(text)) {
            var cur: AccessibilityNodeInfo? = n
            while (cur != null && !cur.isClickable) cur = cur.parent
            if (cur != null && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        return false
    }

    /** Replaces the text of the given / focused / first editable input. Never touches password fields. */
    private fun typeText(id: Int, text: String): Boolean {
        val root = rootInActiveWindow
        val target = (if (id >= 0) node(id) else null)
            ?: root?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: root?.let { r -> findNode(r) { it.isEditable } }
            ?: return false
        if (target.isPassword) {
            toast("Password field e likhbo na")
            return false
        }
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun pressEnter(id: Int): Boolean {
        if (Build.VERSION.SDK_INT < 30) return false
        val target = (if (id >= 0) node(id) else null)
            ?: rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: return false
        return target.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
    }

    private fun scroll(direction: String, id: Int): Boolean {
        val target = (if (id >= 0) node(id) else null)
            ?: rootInActiveWindow?.let { r -> findNode(r) { it.isScrollable } }
            ?: return false
        val act = if (direction == "up" || direction == "left") {
            AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        } else {
            AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        }
        return target.performAction(act)
    }

    private fun swipe(direction: String): Boolean {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val p = when (direction) {
            "up" -> listOf(w / 2, h * 0.9f, w / 2, h * 0.3f)
            "down" -> listOf(w / 2, h * 0.25f, w / 2, h * 0.75f)
            "left" -> listOf(w * 0.8f, h / 2, w * 0.2f, h / 2)
            else -> listOf(w * 0.2f, h / 2, w * 0.8f, h / 2)
        }
        return gesture(p[0], p[1], p[2], p[3], 300)
    }

    private fun tap(x: Int, y: Int): Boolean = gesture(x.toFloat(), y.toFloat(), x.toFloat(), y.toFloat(), 60)

    private fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long): Boolean {
        val path = Path().apply {
            moveTo(x1, y1)
            if (x1 != x2 || y1 != y2) lineTo(x2, y2)
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, ms))
            .build()
        return dispatchGesture(g, null, null)
    }

    /** Turns the screen on. If Face Unlock is set up, looking at the phone unlocks it. */
    @Suppress("DEPRECATION")
    private fun screenOn(): Boolean {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        val wl = pm.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
            "BanglaVoice:wake"
        )
        wl.acquire(5000)
        return true
    }

    private fun findNode(n: AccessibilityNodeInfo, match: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (match(n)) return n
        for (i in 0 until n.childCount) {
            val child = n.getChild(i) ?: continue
            findNode(child, match)?.let { return it }
        }
        return null
    }
}
