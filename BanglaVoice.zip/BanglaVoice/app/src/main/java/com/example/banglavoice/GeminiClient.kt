package com.example.banglavoice

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Plan(val say: String, val actions: List<JSONObject>)

object GeminiClient {
    // Tried in order when the Model field in the app is empty. A 404 means "this model is not
    // available for your key", so the next one is tried. Free-tier models as of Nov 2026.
    private val DEFAULT_MODELS = listOf("gemini-3.5-flash-lite", "gemini-3.8-flash", "gemini-flash-latest")

    @Volatile
    private var working: String? = null

    private class Resp(val code: Int, val text: String)

    private val SYSTEM_PROMPT = """
You control an Android phone for the user. The user speaks Bangla (or Banglish / English).
Convert the request into a JSON plan. Output ONLY JSON in this shape:
{"say":"<one short Bangla sentence about what you will do>","actions":[ ... ]}

Action types (use only these):
{"type":"open_app","app":"<exact label from the Installed apps list>"}
{"type":"open_settings","panel":"wifi|bluetooth|display|sound|battery|main"}
{"type":"open_url","url":"https://..."}
{"type":"dial","number":"+8801XXXXXXXXX"}
{"type":"click_text","text":"<visible text or content description of the button>"}
{"type":"type_text","text":"<text to type into the focused input field>"}
{"type":"scroll","direction":"up|down"}
{"type":"back"} {"type":"home"} {"type":"recents"} {"type":"notifications"}
{"type":"quick_settings"} {"type":"lock"} {"type":"screenshot"}
{"type":"wait","ms":1000}

Rules:
- Translate Bangla app names to the matching English label in the Installed apps list (e.g. হোয়াটসঅ্যাপ -> WhatsApp).
- Keep plans short (max 8 actions). You cannot see the screen, so only use click_text for labels you are confident exist. If unsure, do only the safe first steps and say what is left.
- Never enter passwords, PINs, OTPs or payment details. Never send money, buy things, or delete data. If asked, return empty actions and explain in "say".
- If the request is unclear, return empty actions and ask a short question in "say".
""".trimIndent()

    /** Blocking network call. Run on a background thread. */
    fun plan(ctx: Context, userText: String, apps: List<String>): Plan {
        val key = Prefs.apiKey(ctx)
        require(key.isNotBlank()) { "API key nei, app e dao" }

        val userMsg = "Installed apps: ${apps.joinToString(", ")}\nUser said: $userText"
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM_PROMPT))))
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", userMsg)))
                )
            )
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))

        val custom = Prefs.model(ctx).trim()
        val models = if (custom.isNotEmpty()) listOf(custom) else (listOfNotNull(working) + DEFAULT_MODELS).distinct()

        var lastErr = "Kono model e kaj hoy ni"
        for (m in models) {
            val r = call(key, m, body)
            if (r.code in 200..299) {
                working = m
                return parse(r.text)
            }
            lastErr = "Gemini ${r.code} ($m): ${errorMessage(r.text)}"
            if (r.code != 404) break // only "model not found" is worth trying the next model
        }
        throw RuntimeException(lastErr)
    }

    private fun call(key: String, model: String, body: JSONObject): Resp {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 40000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", key)
        }
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        return Resp(code, text)
    }

    private fun errorMessage(text: String): String = try {
        JSONObject(text).getJSONObject("error").getString("message").take(140)
    } catch (e: Exception) {
        text.take(140)
    }

    private fun parse(resp: String): Plan {
        val text = JSONObject(resp)
            .getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
            .getString("text")
        val j = JSONObject(text)
        val arr = j.optJSONArray("actions") ?: JSONArray()
        val actions = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
        return Plan(j.optString("say"), actions)
    }
}
