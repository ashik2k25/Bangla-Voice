package com.example.banglavoice

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** One turn from the model: a note, the plan, whether the goal is finished, and 1-4 actions to run. */
data class Step(
    val say: String,
    val plan: String,
    val done: Boolean,
    val risky: Boolean,
    val actions: List<JSONObject>
)

/** What Gemini heard in an audio clip. */
data class Heard(val text: String, val wake: Boolean, val kind: String)

object GeminiClient {
    // Free-tier models as of Nov 2026, tried in order. 404 (not available for your key), 429 (this
    // model's free quota is used up) and 503 (busy) move on to the next model.
    private val AGENT_MODELS = listOf("gemini-3.8-flash", "gemini-3.5-flash-lite", "gemini-flash-latest")
    private val HEAR_MODELS = listOf("gemini-3.5-flash-lite", "gemini-3.8-flash", "gemini-flash-latest")

    @Volatile private var workingAgent: String? = null
    @Volatile private var workingHear: String? = null

    private class Resp(val code: Int, val text: String)

    private val AGENT_PROMPT = """
You are Ara, the hands of an Android phone assistant. The user speaks Bangla (or Banglish / English) and wants the phone to do what they ask, using any app, file or setting, like a careful human helper would.
You work in a loop. Every turn you receive the GOAL, your PLAN so far, USER LESSONS, similar tasks that WORKED BEFORE, the HISTORY of actions already done (with results), the SCREEN as a list of elements, and usually a SCREENSHOT of the same moment. Reply with ONLY one JSON object:
{"say":"<short Bangla note for the user, optional>","plan":["step 1","step 2"],"done":false,"risky":false,"actions":[{...},{...}]}
When the goal is finished (or cannot be done) reply: {"say":"<short Bangla result or answer>","done":true}
- "plan": on the FIRST turn of a task write a short plan (3-8 steps). Update it only when it changes.
- "actions": 1 to 4 actions run one after another. Batch only steps whose outcome you can predict (tap the search box, type, press Enter). After anything that opens or changes a screen (open_app, whatsapp_*, share, compose_email, back ...), end the batch and look at the new screen first.

Screen lines look like: [id] Class text="..." desc="..." flags @x,y
flags: click long edit scroll checked unchecked password. @x,y is the element centre on a 0-1000 grid over the screenshot (x from the left, y from the top).

Screen actions (the "type" field):
open_app {app}   exact label from INSTALLED APPS
open_settings {panel: wifi|bluetooth|display|sound|battery|main}
open_url {url}
dial {number}    opens the dialer with the number (does not press call)
click {id}       tap a screen element by its [id]
click_text {text}
long_press {id}
tap {x,y}        tap a point on the 0-1000 grid (only when no element id fits)
type {id?, text} replace the text of input [id] (or the focused / first input)
enter {id?}      press the keyboard Enter / Search key
scroll {direction: down|up|left|right, id?}   direction = which part you want to see: "down" shows content further down the page (a finger swiping up). Feeds and lists are vertical.
swipe {direction: up|down|left|right}   raw finger swipe across the whole screen (e.g. "up" opens the home screen from the lock screen)
back, home, recents, notifications, quick_settings, lock, screenshot
screen_on        wake the screen if it is off
wait {ms}

Direct tools (faster and more reliable than tapping through screens; their result appears in HISTORY):
find_contact {name}        lists matching contacts with phone numbers. Try other spellings or scripts if nothing is found.
whatsapp_call {name, video: true|false}   starts a WhatsApp voice/video call to a contact. Use the exact display name from find_contact. Mark risky.
whatsapp_chat {name}       opens the WhatsApp chat with a contact.
compose_email {to, subject, body}   opens Gmail with the mail filled in. Write subject and body yourself in the language the user wants. Then click Send (risky).
query_photos {count, folder?, minutes?}   picks the newest photos from the gallery (folder = part of the folder name such as Camera, Screenshots, WhatsApp Images; minutes = only photos from the last N minutes).
make_pdf {name}            builds a PDF from the photos picked by query_photos.
share {what: photos|pdf, app, text?}   opens the share sheet of that app with the picked photos or the PDF.
Example: {"say":"WhatsApp khulchi","done":false,"risky":false,"actions":[{"type":"open_app","app":"WhatsApp"}]}

Recipes:
- Call on WhatsApp: find_contact, then whatsapp_call (risky). If it fails, open WhatsApp, search the contact, open the chat and click the call icon (desc "Voice call" or "Video call").
- Message on WhatsApp: find_contact, whatsapp_chat, type the text into the message box, then click Send (risky).
- Email: compose_email, then click Send (risky). If the address is unknown, finish with done:true and ask for it.
- Photos to PDF and share: query_photos, make_pdf, share {what:"pdf", app:"WhatsApp"}; in the app's picker search the contact or group name, select it, then click Send (risky).
- Send gallery photos: query_photos, then share {what:"photos", app}.
- Pictures from one specific WhatsApp group cannot be filtered by a tool: open the group, open its media list and select photos by long-press. Say honestly if that fails.

Rules:
- USER LESSONS come from the user's own corrections and demonstrations. They override your habits. Follow them. WORKED BEFORE is only a hint.
- Read HISTORY, SCREEN and SCREENSHOT. Do not repeat an action that failed twice; try another way. Use the screenshot to understand what the user means. If they point at a specific item (a post, chat, contact, photo, an author name or some text), act only on the buttons that belong to THAT item (in feeds the Like / React / Comment / Share row sits directly under its own post, compare y positions).
- Prefer a direct tool or click by id. If the target is not on screen, open the right app, scroll, or go back.
- Set "risky": true when the batch sends a message/email/post/file, places a call, pays or transfers money, deletes or uninstalls something, or changes security/account settings. Put a risky action alone in its own turn. The user confirms by voice first.
- Never type passwords, PINs, OTPs or card numbers. If the screen needs them, finish with done:true and tell the user to do it themselves.
- If SCREEN says there is no accessible window, the phone may be off or locked: try screen_on, then swipe up.
- If the request needs no phone action (a question), finish with done:true and put the answer in "say". If the request is unclear, finish with done:true and ask a short question in "say".
""".trimIndent()

    private val HEAR_PROMPT = """
You listen to short audio clips from a phone microphone. The assistant's name is Ara (written আরা). The user speaks Bangla, English or a mix. Other people or a TV may also be heard.
Reply with ONLY JSON: {"text":"...","wake":true,"kind":"..."}
"text": what the user said, in the language and script they used, WITHOUT the assistant's name at the start. Empty if nothing meaningful.
"wake": true only if the clip begins with, or clearly calls, the assistant's name (Ara / আরা / আড়া / Aara or a close variant).
"kind" is exactly one of:
command - asks the phone to do something, or asks the assistant a question
stop_task - tells the assistant to stop or cancel what it is doing right now (থামো, থামাও, stop, cancel, বাদ দাও)
end_session - tells the assistant to go to sleep and stop listening (ঘুমাও, বন্ধ হও, bye, আর লাগবে না, ধন্যবাদ আরা)
yes - agrees to a confirmation question (হ্যাঁ, ঠিক আছে, করো)
no - refuses a confirmation question (না, করো না)
lesson - corrects a mistake or teaches how something should be done (ভুল করেছ, এটা না, শেখো, মনে রাখো, স্ক্রল মানে ...)
teach_start - will now demonstrate something on the screen (দেখাচ্ছি, শেখাচ্ছি)
teach_end - the demonstration is finished (শেষ, হয়ে গেছে)
noise - silence, a cough, music, TV, people talking to each other, or anything not meant for the assistant
When unsure whether the speech is meant for the assistant, use noise.
""".trimIndent()

    /** Blocking network call. Run on a background thread. */
    fun next(
        ctx: Context, goal: String, apps: List<String>, history: String, plan: String,
        screen: String, shotB64: String?, lessons: String, skills: String
    ): Step {
        val userMsg = "GOAL: $goal\n\n" +
            "PLAN SO FAR: ${plan.ifBlank { "(none yet, write one)" }}\n\n" +
            "USER LESSONS:\n${lessons.ifBlank { "(none yet)" }}\n\n" +
            "WORKED BEFORE (similar tasks):\n${skills.ifBlank { "(none)" }}\n\n" +
            "INSTALLED APPS: ${apps.joinToString(", ")}\n\n" +
            "HISTORY (oldest first):\n${history.ifBlank { "(none yet)" }}\n\n" +
            "SCREEN NOW:\n$screen"
        val parts = JSONArray().put(JSONObject().put("text", userMsg))
        if (shotB64 != null) {
            parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", shotB64)))
        }
        val body = JSONObject()
            .put("systemInstruction", sys(AGENT_PROMPT))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        val j = JSONObject(clean(generate(ctx, body, agent = true)))

        val acts = ArrayList<JSONObject>()
        j.optJSONArray("actions")?.let { arr ->
            for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { acts.add(it) }
        }
        j.optJSONObject("action")?.let { if (acts.isEmpty()) acts.add(it) }

        val planRaw = j.opt("plan")
        val planText = when (planRaw) {
            is JSONArray -> (0 until planRaw.length()).joinToString(" | ") { planRaw.optString(it) }
            is String -> planRaw
            else -> ""
        }
        return Step(
            j.optString("say"),
            planText,
            j.optBoolean("done", false),
            j.optBoolean("risky", false),
            acts.take(4)
        )
    }

    /** Transcribes and classifies a WAV clip. Blocking; run on a background thread. */
    fun hear(ctx: Context, wav: ByteArray, names: String): Heard {
        val b64 = Base64.encodeToString(wav, Base64.NO_WRAP)
        val parts = JSONArray()
            .put(JSONObject().put("text", "Assistant name variants: $names. Transcribe and classify this clip."))
            .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "audio/wav").put("data", b64)))
        val body = JSONObject()
            .put("systemInstruction", sys(HEAR_PROMPT))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        val j = JSONObject(clean(generate(ctx, body, agent = false)))
        return Heard(j.optString("text"), j.optBoolean("wake", false), j.optString("kind", "noise"))
    }

    private fun sys(text: String): JSONObject =
        JSONObject().put("parts", JSONArray().put(JSONObject().put("text", text)))

    private fun clean(s: String): String =
        s.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()

    /** Sends the request, moving through the model list when a model is missing, rate-limited or busy. */
    private fun generate(ctx: Context, body: JSONObject, agent: Boolean): String {
        val key = Prefs.apiKey(ctx)
        require(key.isNotBlank()) { "API key nei, app e dao" }
        val custom = if (agent) Prefs.model(ctx).trim() else ""
        val base = if (agent) AGENT_MODELS else HEAR_MODELS
        val first = if (agent) workingAgent else workingHear
        val models = if (custom.isNotEmpty()) listOf(custom) else (listOfNotNull(first) + base).distinct()

        var lastErr = "Kono model e kaj hoy ni"
        for (m in models) {
            val r = call(key, m, body)
            if (r.code in 200..299) {
                if (agent) workingAgent = m else workingHear = m
                return JSONObject(r.text)
                    .getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
                    .getString("text")
            }
            lastErr = "Gemini ${r.code} ($m): ${errorMessage(r.text)}"
            if (r.code != 404 && r.code != 429 && r.code != 503) break
        }
        throw RuntimeException(lastErr)
    }

    private fun call(key: String, model: String, body: JSONObject): Resp {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 60000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", key)
        }
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        return Resp(code, text)
    }

    private fun errorMessage(text: String): String = try {
        JSONObject(text).getJSONObject("error").getString("message").take(140)
    } catch (e: Exception) {
        text.take(140)
    }
}
