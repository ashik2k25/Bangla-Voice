package com.example.banglavoice

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** One step from the model: optional note, whether the goal is finished, and the next action. */
data class Step(val say: String, val done: Boolean, val risky: Boolean, val action: JSONObject?)

/** What Gemini heard in an audio clip. */
data class Heard(val text: String, val wake: Boolean, val kind: String)

object GeminiClient {
    // Tried in order when the Model field in the app is empty. A 404 means "this model is not
    // available for your key", so the next one is tried. Free-tier models as of Nov 2026.
    private val DEFAULT_MODELS = listOf("gemini-3.5-flash-lite", "gemini-3.8-flash", "gemini-flash-latest")

    @Volatile
    private var working: String? = null

    private class Resp(val code: Int, val text: String)

    private val AGENT_PROMPT = """
You are Ara, the hands of an Android phone assistant. The user speaks Bangla (or Banglish / English) and wants the phone to do what they ask, using any app or setting.
You work in a loop. Every turn you receive the GOAL, USER LESSONS, the HISTORY of actions already tried, the SCREEN as a list of elements, and usually a SCREENSHOT of the same moment. Reply with ONLY one JSON object:
{"say":"<short Bangla note for the user, optional>","done":false,"risky":false,"action":{...}}
When the goal is finished (or cannot be done) reply: {"say":"<short Bangla result>","done":true}

Screen lines look like: [id] Class text="..." desc="..." flags @x,y
flags: click long edit scroll checked unchecked password. @x,y is the element centre on a 0-1000 grid over the screenshot (x from the left, y from the top).

Actions (the "type" field):
open_app {app}   exact label from INSTALLED APPS
open_settings {panel: wifi|bluetooth|display|sound|battery|main}
open_url {url}
dial {number}    opens the dialer with the number (does not press call)
click {id}       tap a screen element by its [id]
click_text {text}
long_press {id}
tap {x,y}        tap a point on the 0-1000 grid (use only when no element id fits)
type {id?, text} replace the text of input [id] (or the focused / first input)
enter {id?}      press the keyboard Enter / Search key
scroll {direction: down|up|left|right, id?}   direction = which part you want to see: "down" shows content further down the page (like a finger swiping up). Default for feeds and lists is vertical.
swipe {direction: up|down|left|right}   raw finger swipe across the whole screen (e.g. "up" to open the home screen from the lock screen)
back, home, recents, notifications, quick_settings, lock, screenshot
screen_on        wake the screen if it is off
wait {ms}
Example: {"say":"WhatsApp khulchi","done":false,"risky":false,"action":{"type":"open_app","app":"WhatsApp"}}

Rules:
- USER LESSONS come from the user's own corrections and demonstrations. They override your habits. Follow them.
- Do ONE action per turn. Read HISTORY, SCREEN and SCREENSHOT. Do not repeat an action that failed twice; try another way.
- Use the SCREENSHOT to understand what the user means. If they point at a specific item (a post, a chat, a contact, a photo, "this one", "the first one", an author name or some text), find exactly that item on screen and act on the buttons that belong to THAT item. In feeds the Like / React / Comment / Share row sits directly under its own post, so compare y positions and never use another post's buttons. If you cannot tell which item is meant, scroll a little or finish and ask.
- Prefer click by id. If the target is not on screen, open the right app, scroll, or go back.
- Set "risky": true on the action that sends a message/email/post, places a call, pays or transfers money, deletes or uninstalls something, or changes security/account settings. The user confirms by voice first.
- Never type passwords, PINs, OTPs or card numbers. If the screen needs them, finish with done:true and tell the user to do it themselves.
- If SCREEN says there is no accessible window, the phone may be off or locked: try screen_on, then swipe up.
- If the request needs no phone action (a question), finish with done:true and put the answer in "say".
- If the request is unclear, finish with done:true and ask a short question in "say".
""".trimIndent()

    private val HEAR_PROMPT = """
You listen to short audio clips from a phone microphone. The assistant's name is Ara (written আরা). The user speaks Bangla, English or a mix. Other people or a TV may also be heard.
Reply with ONLY JSON: {"text":"...","wake":true,"kind":"..."}
"text": what the user said, in the language and script they used, WITHOUT the assistant's name at the start. Empty if nothing meaningful.
"wake": true only if the clip begins with, or clearly calls, the assistant's name (Ara / আরা / আড়া / Aara or a close variant).
"kind" is exactly one of:
command - asks the phone to do something, or asks the assistant a question
stop_task - tells the assistant to stop or cancel what it is doing right now (থামো, থামাও, stop, cancel, বাদ দাও)
end_session - tells the assistant to go to sleep and stop listening (ঘুমাও, বন্ধ হও, bye, আর লাগবে না, ধন্যবাদ আরা)
yes - agrees to a confirmation question (হ্যাঁ, ঠিক আছে, করো)
no - refuses a confirmation question (না, করো না)
lesson - corrects a mistake or teaches how something should be done (ভুল করেছ, এটা না, শেখো, মনে রাখো, স্ক্রল মানে ...)
teach_start - will now demonstrate something on the screen (দেখাচ্ছি, শেখাচ্ছি)
teach_end - the demonstration is finished (শেষ, হয়ে গেছে)
noise - silence, a cough, music, TV, people talking to each other, or anything not meant for the assistant
When unsure whether the speech is meant for the assistant, use noise.
""".trimIndent()

    /** Blocking network call. Run on a background thread. */
    fun next(
        ctx: Context, goal: String, apps: List<String>, history: String,
        screen: String, shotB64: String?, lessons: String
    ): Step {
        val userMsg = "GOAL: $goal\n\n" +
            "USER LESSONS:\n${lessons.ifBlank { "(none yet)" }}\n\n" +
            "INSTALLED APPS: ${apps.joinToString(", ")}\n\n" +
            "HISTORY (oldest first):\n${history.ifBlank { "(none yet)" }}\n\n" +
            "SCREEN NOW:\n$screen"
        val parts = JSONArray().put(JSONObject().put("text", userMsg))
        if (shotB64 != null) {
            parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", shotB64)))
        }
        val body = JSONObject()
            .put("systemInstruction", sys(AGENT_PROMPT))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        val j = JSONObject(clean(generate(ctx, body)))
        return Step(
            j.optString("say"),
            j.optBoolean("done", false),
            j.optBoolean("risky", false),
            j.optJSONObject("action")
        )
    }

    /** Transcribes and classifies a WAV clip. Blocking; run on a background thread. */
    fun hear(ctx: Context, wav: ByteArray, names: String): Heard {
        val b64 = Base64.encodeToString(wav, Base64.NO_WRAP)
        val parts = JSONArray()
            .put(JSONObject().put("text", "Assistant name variants: $names. Transcribe and classify this clip."))
            .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "audio/wav").put("data", b64)))
        val body = JSONObject()
            .put("systemInstruction", sys(HEAR_PROMPT))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        val j = JSONObject(clean(generate(ctx, body)))
        return Heard(j.optString("text"), j.optBoolean("wake", false), j.optString("kind", "noise"))
    }

    private fun sys(text: String): JSONObject =
        JSONObject().put("parts", JSONArray().put(JSONObject().put("text", text)))

    private fun clean(s: String): String =
        s.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()

    /** Sends the request, falling back through the model list on 404. Returns the model's text. */
    private fun generate(ctx: Context, body: JSONObject): String {
        val key = Prefs.apiKey(ctx)
        require(key.isNotBlank()) { "API key nei, app e dao" }
        val custom = Prefs.model(ctx).trim()
        val models = if (custom.isNotEmpty()) listOf(custom) else (listOfNotNull(working) + DEFAULT_MODELS).distinct()

        var lastErr = "Kono model e kaj hoy ni"
        for (m in models) {
            val r = call(key, m, body)
            if (r.code in 200..299) {
                working = m
                return JSONObject(r.text)
                    .getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
                    .getString("text")
            }
            lastErr = "Gemini ${r.code} ($m): ${errorMessage(r.text)}"
            if (r.code != 404) break // only "model not found" is worth trying the next model
        }
        throw RuntimeException(lastErr)
    }

    private fun call(key: String, model: String, body: JSONObject): Resp {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 45000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", key)
        }
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        return Resp(code, text)
    }

    private fun errorMessage(text: String): String = try {
        JSONObject(text).getJSONObject("error").getString("message").take(140)
    } catch (e: Exception) {
        text.take(140)
    }
}
