package com.example.banglavoice

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Plan(val say: String, val actions: List<JSONObject>)

object GeminiClient {
    // Change here if Google renames/retires the model. Pick any model that is free in AI Studio.
    private const val MODEL = "gemini-2.5-flash"

    private val SYSTEM_PROMPT = """
You control an Android phone for the user. The user speaks Bangla (or Banglish / English).
Convert the request into a JSON plan. Output ONLY JSON in this shape:
{"say":"<one short Bangla sentence about what you will do>","actions":[ ... ]}

Action types (use only these):
{"type":"open_app","app":"<exact label from the Installed apps list>"}
{"type":"open_settings","panel":"wifi|bluetooth|display|sound|battery|main"}
{"type":"open_url","url":"https://..."}
{"type":"dial","number":"+8801XXXXXXXXX"}
{"type":"click_text","text":"<visible text or content description of the button>"}
{"type":"type_text","text":"<text to type into the focused input field>"}
{"type":"scroll","direction":"up|down"}
{"type":"back"} {"type":"home"} {"type":"recents"} {"type":"notifications"}
{"type":"quick_settings"} {"type":"lock"} {"type":"screenshot"}
{"type":"wait","ms":1000}

Rules:
- Translate Bangla app names to the matching English label in the Installed apps list (e.g. হোয়াটসঅ্যাপ -> WhatsApp).
- Keep plans short (max 8 actions). You cannot see the screen, so only use click_text for labels you are confident exist. If unsure, do only the safe first steps and say what is left.
- Never enter passwords, PINs, OTPs or payment details. Never send money, buy things, or delete data. If asked, return empty actions and explain in "say".
- If the request is unclear, return empty actions and ask a short question in "say".
""".trimIndent()

    /** Blocking network call. Run on a background thread. */
    fun plan(ctx: Context, userText: String, apps: List<String>): Plan {
        val key = Prefs.apiKey(ctx)
        require(key.isNotBlank()) { "API key nei, app e dao" }

        val userMsg = "Installed apps: ${apps.joinToString(", ")}\nUser said: $userText"
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM_PROMPT))))
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", userMsg)))
                )
            )
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("temperature", 0.1))

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 40000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", key)
        }
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val resp = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw RuntimeException("Gemini $code: ${resp.take(200)}")

        val text = JSONObject(resp)
            .getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
            .getString("text")
        val j = JSONObject(text)
        val arr = j.optJSONArray("actions") ?: JSONArray()
        val actions = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
        return Plan(j.optString("say"), actions)
    }
}
