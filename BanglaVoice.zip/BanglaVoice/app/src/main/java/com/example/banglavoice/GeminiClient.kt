package com.example.banglavoice

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** One step from the model: optional note, whether the goal is finished, and the next action. */
data class Step(val say: String, val done: Boolean, val risky: Boolean, val action: JSONObject?)

object GeminiClient {
    // Tried in order when the Model field in the app is empty. A 404 means "this model is not
    // available for your key", so the next one is tried. Free-tier models as of Nov 2026.
    private val DEFAULT_MODELS = listOf("gemini-3.5-flash-lite", "gemini-3.8-flash", "gemini-flash-latest")

    @Volatile
    private var working: String? = null

    private class Resp(val code: Int, val text: String)

    private val SYSTEM_PROMPT = """
You are Ara, the hands of an Android phone assistant. The user speaks Bangla (or Banglish / English) and wants the phone to do what they ask, using any app or setting.
You work in a loop. Every turn you receive the GOAL, the HISTORY of actions already tried, and the SCREEN as it is right now. Reply with ONLY one JSON object:
{"say":"<short Bangla note for the user, optional>","done":false,"risky":false,"action":{...}}
When the goal is finished (or cannot be done) reply: {"say":"<short Bangla result>","done":true}

Screen lines look like: [id] Class text="..." desc="..." flags @x,y   (flags: click long edit scroll checked unchecked password). x,y is the centre in pixels.

Actions (the "type" field):
open_app {app}   exact label from INSTALLED APPS
open_settings {panel: wifi|bluetooth|display|sound|battery|main}
open_url {url}
dial {number}    opens the dialer with the number (does not press call)
click {id}       tap a screen element by its [id]
click_text {text}
long_press {id}
tap {x,y}        tap a pixel position when nothing else works
type {id?, text} replace the text of input [id] (or the focused / first input)
enter {id?}      press the keyboard Enter / Search key
scroll {direction: up|down|left|right, id?}
swipe {direction: up|down|left|right}   swipe the whole screen (e.g. swipe up on the lock screen)
back, home, recents, notifications, quick_settings, lock, screenshot
screen_on        wake the screen if it is off
wait {ms}
Example: {"say":"WhatsApp khulchi","done":false,"risky":false,"action":{"type":"open_app","app":"WhatsApp"}}

Rules:
- Do ONE action per turn. Read HISTORY and SCREEN. Do not repeat an action that failed twice; try another way.
- Prefer click by id. If the target is not on screen, open the right app, scroll, or go back.
- Set "risky": true on the action that sends a message/email/post, places a call, pays or transfers money, deletes or uninstalls something, or changes security/account settings. The user confirms by voice first.
- Never type passwords, PINs, OTPs or card numbers. If the screen needs them, finish with done:true and tell the user to do it themselves.
- If SCREEN says there is no accessible window, the phone may be off or locked: try screen_on, then swipe up.
- If the request needs no phone action (a question), finish with done:true and put the answer in "say".
- If the request is unclear, finish with done:true and ask a short question in "say".
""".trimIndent()

    /** Blocking network call. Run on a background thread. */
    fun next(ctx: Context, goal: String, apps: List<String>, history: String, screen: String): Step {
        val key = Prefs.apiKey(ctx)
        require(key.isNotBlank()) { "API key nei, app e dao" }

        val userMsg = "GOAL: $goal\n\n" +
            "INSTALLED APPS: ${apps.joinToString(", ")}\n\n" +
            "HISTORY (oldest first):\n${history.ifBlank { "(none yet)" }}\n\n" +
            "SCREEN NOW:\n$screen"
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM_PROMPT))))
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", userMsg)))
                )
            )
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))

        val custom = Prefs.model(ctx).trim()
        val models = if (custom.isNotEmpty()) listOf(custom) else (listOfNotNull(working) + DEFAULT_MODELS).distinct()

        var lastErr = "Kono model e kaj hoy ni"
        for (m in models) {
            val r = call(key, m, body)
            if (r.code in 200..299) {
                working = m
                return parse(r.text)
            }
            lastErr = "Gemini ${r.code} ($m): ${errorMessage(r.text)}"
            if (r.code != 404) break // only "model not found" is worth trying the next model
        }
        throw RuntimeException(lastErr)
    }

    private fun call(key: String, model: String, body: JSONObject): Resp {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 40000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", key)
        }
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        return Resp(code, text)
    }

    private fun errorMessage(text: String): String = try {
        JSONObject(text).getJSONObject("error").getString("message").take(140)
    } catch (e: Exception) {
        text.take(140)
    }

    private fun parse(resp: String): Step {
        val raw = JSONObject(resp)
            .getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
            .getString("text")
        val text = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val j = JSONObject(text)
        return Step(
            j.optString("say"),
            j.optBoolean("done", false),
            j.optBoolean("risky", false),
            j.optJSONObject("action")
        )
    }
}
