# BanglaVoice v3

"Ara" bole dako -> bip -> kotha bolo. Ara jaga thake (bar bar dakte hobe na) jotokkhon na 'ghumao' bolo.
Ara screen dekhe (element list + screenshot) dhape dhape kaj kore.

## Setup (app e)
1. Gemini API key dao, Save.
2. Mic + notification permission.
3. Accessibility ON (BanglaVoice). Na hole: Settings > Apps > BanglaVoice > menu > Allow restricted settings.
4. Hands-free nije shuru hoy. Battery: Unrestricted rakho.

## Safety
- Risky kaj (message pathano, call, payment, delete) er age voice confirm chay.
- Password/PIN/OTP field e likhe na.
- Screenshot ar audio clip Gemini (Google) e jay. Banking/OTP screen e use koro na.
