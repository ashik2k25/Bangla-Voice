# BanglaVoice v4

"Ara" bole dako -> bip -> kotha bolo. Ara jaga thake jotokkhon na 'ghumao' bolo.

Ara screen dekhe (element list + screenshot) kaj kore, ar shortcut tool o ache:
contacts khoja, WhatsApp voice/video call ba chat, email lekha, gallery photo, PDF banano, share kora.
Egulo dhape dhape UI tap kora theke onek druto o nirbhorjogyo.

## Setup (app e)
1. Gemini API key dao, Save (key phone er Keystore e encrypted thake).
2. "Permission dao" chapo: mic, contacts, photos ("Allow all").
3. Accessibility ON (BanglaVoice). Na hole: Settings > Apps > BanglaVoice > menu > Allow restricted settings.
4. Hands-free nije shuru hoy. Battery: Unrestricted rakho.

## Safety
- Risky kaj (message/email/file pathano, call, payment, delete) er age voice confirm chay.
- Password/PIN/OTP field e likhe na.
- Screenshot, audio clip ar screen er lekha Gemini (Google) e jay. Banking/OTP screen e use koro na.
