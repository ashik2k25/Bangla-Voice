# BanglaVoice (Phase 1)

Mic button -> Bangla speech -> Gemini (free tier) -> accessibility actions.

## Run
1. Android Studio (free) diye ei folder ta open koro (File > Open). Gradle sync hote dao.
2. Phone: Settings > About phone > Build number 7 bar tap > Developer options > USB debugging ON.
3. USB diye connect kore Run (green play).
4. App e: Gemini API key dao (aistudio.google.com/apikey), Save, Mic permission, Accessibility ON.
   - Accessibility ON na hole: Settings > Apps > BanglaVoice > top-right menu > Allow restricted settings.
   - Android Advanced Protection OFF thakte hobe.
5. Nil mic button e tap kore bolo.

## Test commands
- "হোয়াটসঅ্যাপ খোলো"
- "ওয়াইফাই সেটিংস খোলো"
- "স্ক্রিনশট নাও" / "ফোন লক করো"
- "নিচে স্ক্রল করো"
- "গুগলে বাংলাদেশের আবহাওয়া খোঁজো"

## Safety
Gemini free tier request Google product improve korte use korte pare. Banking, OTP, password screen e use koro na.
Password field e app type kore na.
