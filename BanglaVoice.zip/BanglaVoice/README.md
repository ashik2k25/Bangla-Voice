# BanglaVoice v2

Nam dhore dako ("Ara") ba nil button e tap -> Bangla bolo -> Gemini screen dekhe dhape dhape kaj kore.

## Setup (app e)
1. Gemini API key dao (aistudio.google.com/apikey), Save.
2. Mic + notification permission.
3. Accessibility ON (BanglaVoice). Na hole: Settings > Apps > BanglaVoice > menu > Allow restricted settings.
4. "Hands-free CHALU" chapo. Battery: Unrestricted rakho.

## Safety
- Risky kaj (message pathano, call, payment, delete) er age voice confirm ("hya"/"na") chay.
- Password/PIN/OTP field e likhe na.
- Free tier e Google request ke product improve korte use korte pare. Banking/OTP screen e use koro na.
